<?php
/**
 * Bulk Booking Modal Template
 */

defined('ABSPATH') or die('No direct script access allowed!');
?>

<div id="trax-bulk-modal" class="trax-modal">
    <div class="trax-modal-content trax-modal-large">
        <div class="trax-modal-header">
            <h2>Bulk Shipment</h2>
            <span class="trax-modal-close">&times;</span>
        </div>
        
        <div class="trax-modal-body">
            <div class="trax-bulk-shipment-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Destination City</th>
                            <th>Customer Name</th>
                            <th>Phone</th>
                            <th>Shipment Type</th>
                            <th>Actual Price</th>
                            <th>Weight (kg)</th>
                            <th>Status</th>
                            <th style="width:40px;">Details</th>
                            <th style="width:40px;">Remove</th>
                        </tr>
                    </thead>
                    <tbody id="trax-bulk-orders-tbody">
                        <!-- Orders will be populated here -->
                    </tbody>
                </table>
            </div>
            
            <div id="trax-bulk-response" style="display:none;"></div>
        </div>
        
        <div class="trax-modal-footer">
            <button type="button" class="button button-primary" id="trax-bulk-submit-btn">Create Bulk Shipment</button>
        </div>
    </div>
</div>
