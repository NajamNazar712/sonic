<?php
/**
 * Single Booking Modal Template
 */

defined('ABSPATH') or die('No direct script access allowed!');
?>

<div id="trax-booking-modal" class="trax-modal">
    <div class="trax-modal-content">
        <div class="trax-modal-header">
            <h2>Book Shipment</h2>
            <span class="trax-modal-close">&times;</span>
        </div>
        
        <div class="trax-modal-body">
            <form id="trax-booking-form" novalidate>
                <input type="hidden" id="trax-order-id" name="order_id" value="">
                
                <table class="form-table">
                    <tr>
                        <th><label for="trax-destination-city">Destination City *</label></th>
                        <td>
                            <select id="trax-destination-city" name="consignee_city_id" style="width: 100%;">
                                <option value="">— Select Destination City —</option>
                            </select>
                            <span class="trax-field-error" id="trax-destination-city-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-shipping-mode">Shipment Type *</label></th>
                        <td>
                            <select id="trax-shipping-mode" name="shipping_mode_id" required style="width: 100%;">
                                <option value="1">Rush</option>
                                <option value="2">Saver Plus</option>
                                <option value="3">Swift</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-consignee-name">Consignee Name *</label></th>
                        <td>
                            <input type="text" id="trax-consignee-name" name="consignee_name" required style="width: 100%;">
                            <span class="trax-field-error" id="trax-consignee-name-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-consignee-address">Consignee Address *</label></th>
                        <td>
                            <textarea id="trax-consignee-address" name="consignee_address" rows="3" required style="width: 100%;"></textarea>
                            <span class="trax-field-error" id="trax-consignee-address-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-consignee-phone">Consignee Phone *</label></th>
                        <td>
                            <input type="text" id="trax-consignee-phone" name="consignee_phone"
                                   placeholder="03xxxxxxxxx" style="width: 100%;">
                            <span class="trax-field-error" id="trax-consignee-phone-error"></span>
                            <p class="description">Format: 03xxxxxxxxx (11 digits) or +92xxxxxxxxxx</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-consignee-email">Consignee Email</label></th>
                        <td>
                            <input type="email" id="trax-consignee-email" name="consignee_email" style="width: 100%;">
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-amount">COD Amount *</label></th>
                        <td>
                            <input type="number" id="trax-amount" name="amount" step="0.01" required style="width: 100%;">
                            <span class="trax-field-error" id="trax-amount-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-parcel-value">Parcel Value *</label></th>
                        <td>
                            <input type="number" id="trax-parcel-value" name="parcel_value" step="0.01" required style="width: 100%;">
                            <span class="trax-field-error" id="trax-parcel-value-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-item-description">Item Description *</label></th>
                        <td>
                            <textarea id="trax-item-description" name="item_description" rows="3" required style="width: 100%;"></textarea>
                            <span class="trax-field-error" id="trax-item-description-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-item-quantity">Item Quantity *</label></th>
                        <td>
                            <input type="number" id="trax-item-quantity" name="item_quantity" min="1" required style="width: 100%;">
                            <span class="trax-field-error" id="trax-item-quantity-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-estimated-weight">Estimated Weight (kg) *</label></th>
                        <td>
                            <input type="number" id="trax-estimated-weight" name="estimated_weight" step="0.01" min="0.1" required style="width: 100%;">
                            <span class="trax-field-error" id="trax-estimated-weight-error"></span>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="trax-special-instructions">Special Instructions</label></th>
                        <td>
                            <textarea id="trax-special-instructions" name="special_instructions" rows="2" style="width: 100%;"></textarea>
                        </td>
                    </tr>
                </table>
            </form>
            
            <div id="trax-preview-section" style="display:none;">
                <h3>Preview Order Details</h3>
                <div id="trax-preview-content"></div>
            </div>
            
            <div id="trax-response-message" style="display:none;"></div>
        </div>
        
        <div class="trax-modal-footer">
            <button type="button" class="button" id="trax-preview-btn">Preview</button>
            <button type="button" class="button button-primary" id="trax-submit-btn" style="display:none;">Submit</button>
            <button type="button" class="button" id="trax-back-btn" style="display:none;">Back</button>
        </div>
    </div>
</div>
