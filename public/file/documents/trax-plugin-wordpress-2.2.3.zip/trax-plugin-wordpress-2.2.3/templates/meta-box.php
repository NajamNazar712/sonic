<?php
/**
 * Meta Box Template
 */

defined('ABSPATH') or die('No direct script access allowed!');
?>

<div class="trax-meta-box">
    <?php if ($tracking_number): ?>
        <p>
            <strong>Tracking Number:</strong><br>
            <a href="<?php echo esc_url(trax_tracking_url($tracking_number)); ?>" target="_blank">
                <?php echo esc_html($tracking_number); ?>
            </a>
        </p>
        <p>
            <button type="button" class="button trax-download-airway-bill" data-tracking="<?php echo esc_attr($tracking_number); ?>">
                📄 Download Airway Bill
            </button>
        </p>
        <p>
            <button type="button" class="button trax-cancel-shipment" data-tracking="<?php echo esc_attr($tracking_number); ?>" data-order-id="<?php echo esc_attr($order->get_id()); ?>" style="color:#a00; border-color:#a00;">
                ✕ Cancel Shipment
            </button>
        </p>
    <?php else: ?>
        <p>No shipment booked yet.</p>
        <button type="button" class="button button-primary trax-create-shipment" data-order-id="<?php echo esc_attr($order->get_id()); ?>">
            Create Shipment
        </button>
    <?php endif; ?>
</div>
