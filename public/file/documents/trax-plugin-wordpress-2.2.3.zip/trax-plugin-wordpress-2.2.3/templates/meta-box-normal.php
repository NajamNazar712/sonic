<?php
/**
 * Meta Box Normal Template (larger version)
 */

defined('ABSPATH') or die('No direct script access allowed!');
?>

<div class="trax-meta-box-normal" style="padding: 15px;">
    <?php if ($tracking_number): ?>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <p style="margin: 0 0 10px 0;">
                    <strong style="font-size: 14px;">Tracking Number:</strong><br>
                    <a href="<?php echo esc_url(trax_tracking_url($tracking_number)); ?>" 
                       target="_blank" 
                       style="font-size: 16px; font-weight: 600; color: #0073aa; text-decoration: none;">
                        <?php echo esc_html($tracking_number); ?>
                    </a>
                </p>
                <p style="margin: 0; color: #666; font-size: 13px;">
                    ✅ Shipment booked successfully with Trax
                </p>
            </div>
            <div style="display:flex; gap:8px; align-items:center;">
                <button type="button" 
                        class="button button-primary trax-download-airway-bill" 
                        data-tracking="<?php echo esc_attr($tracking_number); ?>"
                        style="height: 40px;">
                    📄 Download Airway Bill
                </button>
                <button type="button"
                        class="button trax-cancel-shipment"
                        data-tracking="<?php echo esc_attr($tracking_number); ?>"
                        data-order-id="<?php echo esc_attr($order->get_id()); ?>"
                        style="height:40px; color:#a00; border-color:#a00;">
                    ✕ Cancel Shipment
                </button>
            </div>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 20px 0;">
            <p style="margin: 0 0 15px 0; font-size: 14px; color: #666;">
                No shipment booked yet with Trax
            </p>
            <button type="button" 
                    class="button button-primary button-large trax-create-shipment" 
                    data-order-id="<?php echo esc_attr($order->get_id()); ?>"
                    style="height: 45px; font-size: 14px;">
                📦 Create Shipment
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.trax-meta-box-normal {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.trax-meta-box-normal a:hover {
    text-decoration: underline !important;
}
.trax-cancel-shipment:hover {
    background: #a00 !important;
    color: #fff !important;
}
</style>
