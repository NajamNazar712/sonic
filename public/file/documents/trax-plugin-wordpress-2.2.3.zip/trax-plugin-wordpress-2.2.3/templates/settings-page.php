<?php
/**
 * Settings Page Template
 */

defined('ABSPATH') or die('No direct script access allowed!');
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form method="post" action="options.php">
        <?php
        settings_fields('trax_settings');
        do_settings_sections('trax_settings');
        ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="trax_api_key">API Key</label>
                </th>
                <td>
                    <input type="text" 
                           id="trax_api_key" 
                           name="trax_api_key" 
                           value="<?php echo esc_attr(get_option('trax_api_key')); ?>" 
                           class="regular-text" 
                           required />
                    <p class="description">Enter your Trax Sonic API key</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="trax_base_url">Base URL</label>
                </th>
                <td>
                    <input type="url" 
                           id="trax_base_url" 
                           name="trax_base_url" 
                           value="<?php echo esc_attr(get_option('trax_base_url', 'https://sonic.pk/')); ?>" 
                           class="regular-text" 
                           placeholder="https://sonic.pk/" />
                    <p class="description">API base URL. Default: <code>https://sonic.pk/</code> — change only if instructed (e.g. <code>https://app.sonic.pk/</code>)</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="trax_pickup_address_id">Pickup Address</label>
                </th>
                <td>
                    <?php if (isset($error_message)): ?>
                        <p style="color: red;">⚠️ Could not load pickup addresses: <?php echo esc_html($error_message); ?></p>
                        <p>Please enter your Pickup Address ID manually:</p>
                        <input type="text" 
                               id="trax_pickup_address_id" 
                               name="trax_pickup_address_id" 
                               value="<?php echo esc_attr(get_option('trax_pickup_address_id')); ?>" 
                               class="regular-text" 
                               placeholder="e.g., 625362" />
                    <?php else: ?>
                        <select id="trax_pickup_address_id" name="trax_pickup_address_id" required>
                            <option value="">Select Pickup Address</option>
                            <?php
                            if (!empty($pickup_addresses)) {
                                $current_address = get_option('trax_pickup_address_id');
                                foreach ($pickup_addresses as $address) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($address['id']),
                                        selected($current_address, $address['id'], false),
                                        esc_html($address['address'])
                                    );
                                }
                            }
                            ?>
                        </select>
                    <?php endif; ?>
                    <p class="description">Select your default pickup address (or enter ID manually if dropdown is empty)</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="trax_default_shipping_mode">Default Shipping Mode</label>
                </th>
                <td>
                    <select id="trax_default_shipping_mode" name="trax_default_shipping_mode">
                        <?php
                        $current_mode = get_option('trax_default_shipping_mode', '1');
                        $modes = array(
                            '1' => 'Rush',
                            '2' => 'Saver Plus',
                            '3' => 'Swift'
                        );
                        foreach ($modes as $value => $label) {
                            printf(
                                '<option value="%s" %s>%s</option>',
                                esc_attr($value),
                                selected($current_mode, $value, false),
                                esc_html($label)
                            );
                        }
                        ?>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="trax_enable_debug">Enable Debug Logging</label>
                </th>
                <td>
                    <input type="checkbox" 
                           id="trax_enable_debug" 
                           name="trax_enable_debug" 
                           value="yes" 
                           <?php checked(get_option('trax_enable_debug'), 'yes'); ?> />
                    <p class="description">Log file: wp-content/uploads/trax-debug.log</p>
                </td>
            </tr>
        </table>
        
        <?php submit_button(); ?>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    var fetchTimeout;
    var lastApiKey = '';
    
    // Auto-fetch pickup addresses when API key changes
    $('#trax_api_key').on('input', function() {
        var apiKey = $(this).val().trim();
        
        // Clear previous timeout
        clearTimeout(fetchTimeout);
        
        // Only fetch if key is long enough (at least 20 chars)
        if (apiKey.length < 20) {
            return;
        }
        
        // Don't fetch if same as last key
        if (apiKey === lastApiKey) {
            return;
        }
        
        lastApiKey = apiKey;
        
        // Wait 1 second after user stops typing
        fetchTimeout = setTimeout(function() {
            fetchPickupAddresses(apiKey);
        }, 1000);
    });
    
    function fetchPickupAddresses(apiKey) {
        var $select = $('#trax_pickup_address_id');
        var $container = $select.parent();
        
        // Show loading
        $container.find('.trax-fetch-status').remove();
        $container.append('<span class="trax-fetch-status" style="color: #0073aa; margin-left: 10px;">⏳ Fetching addresses...</span>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_fetch_pickup_addresses',
                nonce: '<?php echo wp_create_nonce('trax_nonce'); ?>',
                api_key: apiKey
            },
            success: function(response) {
                $container.find('.trax-fetch-status').remove();
                
                if (response.success) {
                    // Populate dropdown
                    var html = '<option value="">Select Pickup Address</option>';
                    $.each(response.data.addresses, function(index, address) {
                        html += '<option value="' + address.id + '">' + address.address + '</option>';
                    });
                    
                    // Replace input with select if it's an input
                    if ($select.is('input')) {
                        var currentValue = $select.val();
                        $select.replaceWith('<select id="trax_pickup_address_id" name="trax_pickup_address_id" required>' + html + '</select>');
                        $select = $('#trax_pickup_address_id');
                        if (currentValue) {
                            $select.val(currentValue);
                        }
                    } else {
                        $select.html(html);
                    }
                    
                    $container.append('<span class="trax-fetch-status" style="color: #46b450; margin-left: 10px;">✓ Loaded ' + response.data.addresses.length + ' addresses</span>');
                    
                    setTimeout(function() {
                        $container.find('.trax-fetch-status').fadeOut(function() {
                            $(this).remove();
                        });
                    }, 3000);
                } else {
                    $container.append('<span class="trax-fetch-status" style="color: #dc3232; margin-left: 10px;">✗ ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $container.find('.trax-fetch-status').remove();
                $container.append('<span class="trax-fetch-status" style="color: #dc3232; margin-left: 10px;">✗ Failed to fetch addresses</span>');
            }
        });
    }
});
</script>
