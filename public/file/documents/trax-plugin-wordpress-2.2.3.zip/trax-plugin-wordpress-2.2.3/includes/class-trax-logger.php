<?php
/**
 * Trax Logger Class
 * 
 * @package TraxLogistics
 */

defined('ABSPATH') or die('No direct script access allowed!');

class Trax_Logger {
    
    /**
     * Log file path
     */
    private static function get_log_file() {
        $upload_dir = wp_upload_dir();
        return $upload_dir['basedir'] . '/trax-debug.log';
    }
    
    /**
     * Write log entry
     * 
     * @param string $message
     * @param mixed $data
     */
    public static function log($message, $data = null) {
        // Check if debug is enabled
        if (get_option('trax_enable_debug') !== 'yes') {
            return;
        }
        
        $log_file = self::get_log_file();
        $timestamp = date('Y-m-d H:i:s');
        $entry = "[{$timestamp}] {$message}";
        
        if ($data !== null) {
            if (is_array($data) || is_object($data)) {
                $entry .= ' | ' . wp_json_encode($data);
            } else {
                $entry .= ' | ' . $data;
            }
        }
        
        error_log($entry . PHP_EOL, 3, $log_file);
    }
    
    /**
     * Clear log file
     */
    public static function clear_log() {
        $log_file = self::get_log_file();
        if (file_exists($log_file)) {
            unlink($log_file);
        }
    }
}
