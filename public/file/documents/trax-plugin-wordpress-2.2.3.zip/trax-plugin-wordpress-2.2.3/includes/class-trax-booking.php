<?php
/**
 * Trax Booking Class
 * 
 * @package TraxLogistics
 */

defined('ABSPATH') or die('No direct script access allowed!');

class Trax_Booking {
    
    /**
     * Register custom order status
     */
    public static function register_order_status() {
        register_post_status('wc-trax-booked', array(
            'label' => 'Booked at Trax',
            'public' => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list' => true,
            'exclude_from_search' => false,
            'label_count' => _n_noop('Booked at Trax <span class="count">(%s)</span>', 'Booked at Trax <span class="count">(%s)</span>')
        ));
    }
    
    /**
     * Add custom status to order statuses
     */
    public static function add_order_status($order_statuses) {
        $new_statuses = array();
        
        foreach ($order_statuses as $key => $status) {
            $new_statuses[$key] = $status;
            if ('wc-processing' === $key) {
                $new_statuses['wc-trax-booked'] = 'Booked at Trax';
            }
        }
        
        return $new_statuses;
    }
    
    /**
     * Get order weight
     */
    public static function get_order_weight($order) {
        $total_weight = 0;
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product) {
                $weight = (float) $product->get_weight();
                $quantity = (int) $item->get_quantity();
                $total_weight += $weight * $quantity;
            }
        }
        
        return $total_weight > 0 ? $total_weight : 1;
    }
    
    /**
     * Get order items description
     */
    public static function get_order_items_description($order) {
        $items = array();
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product) {
                $items[] = $item->get_quantity() . ' X ' . $product->get_name();
            }
        }
        
        return implode(', ', $items);
    }
    
    /**
     * Get order data for booking
     */
    public static function get_order_booking_data($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return false;
        }
        
        $data = $order->get_data();
        
        // Get customer details - fall back to billing if shipping is empty (same as old plugin)
        $first_name = !empty(trim($data['shipping']['first_name'])) ? $data['shipping']['first_name'] : $data['billing']['first_name'];
        $last_name  = !empty(trim($data['shipping']['last_name']))  ? $data['shipping']['last_name']  : $data['billing']['last_name'];
        $address_1  = !empty(trim($data['shipping']['address_1']))  ? $data['shipping']['address_1']  : $data['billing']['address_1'];
        $address_2  = !empty(trim($data['shipping']['address_2']))  ? $data['shipping']['address_2']  : $data['billing']['address_2'];
        $phone      = !empty(trim($data['shipping']['phone']))      ? $data['shipping']['phone']      : $data['billing']['phone'];
        $email      = !empty(trim($data['shipping']['email']))      ? $data['shipping']['email']      : $data['billing']['email'];
        $city       = !empty(trim($data['shipping']['city']))       ? $data['shipping']['city']       : $data['billing']['city'];
        
        // has_shipping_city: only true if shipping city specifically is set
        // This controls whether city auto-matches in the dropdown
        // If both shipping and billing city are empty → city is '' → dropdown stays empty + highlighted
        $has_shipping_city = !empty(trim($data['shipping']['city']));
        
        // Calculate totals
        $item_total = 0;
        $item_quantity = 0;
        foreach ($order->get_items() as $item) {
            $item_quantity += $item->get_quantity();
            $item_total += $item->get_subtotal();
        }
        
        return array(
            'order_id'           => $order->get_id(),
            'order_number'       => $order->get_order_number(),
            'consignee_name'     => trim($first_name . ' ' . $last_name),
            'consignee_address'  => trim($address_1 . ' ' . $address_2),
            'consignee_phone'    => $phone,
            'consignee_email'    => $email,
            'consignee_city'     => $city,
            'has_shipping_city'  => $has_shipping_city, // true = from shipping city specifically
            'amount'             => $order->get_total(),
            'parcel_value'       => $item_total,
            'item_description'   => self::get_order_items_description($order),
            'item_quantity'      => $item_quantity,
            'estimated_weight'   => self::get_order_weight($order),
            'special_instructions' => $order->get_customer_note(),
            'payment_method'     => $order->get_payment_method_title()
        );
    }
    
    /**
     * Book shipment
     */
    public static function book_shipment($order_id, $booking_data) {
        $api = new Trax_API();
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return array('success' => false, 'message' => 'Order not found');
        }
        
        // Prepare API data
        $api_data = array(
            'order_id'             => $order->get_order_number(),
            'service_type_id'      => 1,
            'shipping_mode_id'     => (int)   $booking_data['shipping_mode_id'],
            'pickup_address_id'    => get_option('trax_pickup_address_id'),
            'information_display'  => 1,
            'consignee_city_id'    => (int)   $booking_data['consignee_city_id'],
            'consignee_name'       =>          $booking_data['consignee_name'],
            'consignee_address'    =>          $booking_data['consignee_address'],
            'consignee_phone_number_1' =>      $booking_data['consignee_phone'],
            'item_product_type_id' => 24,
            'item_description'     =>          $booking_data['item_description'],
            'item_quantity'        => (int)   $booking_data['item_quantity'],
            'item_insurance'       => 0,
            'estimated_weight'     => (float) $booking_data['estimated_weight'],
            'pickup_date'          => date('Y-m-d'),
            'payment_mode_id'      => 1
        );
        
        // Add email if provided
        if (!empty($booking_data['consignee_email'])) {
            $api_data['consignee_email_address'] = $booking_data['consignee_email'];
        }
        
        // Add special instructions if provided
        if (!empty($booking_data['special_instructions'])) {
            $api_data['special_instructions'] = $booking_data['special_instructions'];
        }
        
        // Determine COD amount and parcel value
        // Use the amount entered by the user in the modal directly
        // If amount > 0 → it's a COD order, send amount
        // If amount == 0 → prepaid, send parcel_value instead
        $payment_title  = strtolower($order->get_payment_method_title());
        $payment_method = strtolower($order->get_payment_method());
        
        $amount_val  = isset($booking_data['amount'])       ? trim($booking_data['amount'])       : '';
        $parcel_val  = isset($booking_data['parcel_value']) ? trim($booking_data['parcel_value']) : '';
        $amount_float = ($amount_val !== '') ? (float) $amount_val : 0;
        
        Trax_Logger::log('Payment method title', $payment_title);
        Trax_Logger::log('Payment method', $payment_method);
        Trax_Logger::log('Booking data amount', $amount_val);
        Trax_Logger::log('Booking data parcel_value', $parcel_val);
        
        if ($amount_float > 0) {
            // Amount entered — send as COD amount
            $api_data['amount'] = $amount_float;
            Trax_Logger::log('Amount > 0 - sending as COD amount', $api_data['amount']);
        } else {
            // Amount is 0 — prepaid, send parcel_value
            $api_data['amount'] = 0;
            $parcel_value = ($parcel_val !== '') ? (int) $parcel_val : 0;
            $api_data['parcel_value'] = ($parcel_value > 0) ? $parcel_value : 1;
            Trax_Logger::log('Amount = 0 - sending parcel_value', $api_data['parcel_value']);
        }
        
        Trax_Logger::log('Booking shipment for order', $order_id);
        
        $response = $api->book_shipment($api_data);
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        if (isset($response['status']) && $response['status'] == 0) {
            // Success
            $tracking_number = $response['tracking_number'];
            
            // Update order meta
            $order->update_meta_data('_trax_tracking_number', $tracking_number);
            $order->update_meta_data('_trax_booked_by', 'Trax');
            $order->update_meta_data('_trax_previous_status', $order->get_status()); // save for restore on cancel
            $order->save();
            
            // Build order note with all messages
            $note = sprintf(
                'Shipment booked at Trax. Tracking Number: %s. <a href="%s" target="_blank">Track Shipment</a>',
                $tracking_number,
                trax_tracking_url($tracking_number)
            );
            
            // Add warning messages if present
            $warnings = array();
            
            if (isset($response['non_service_area'])) {
                $warnings[] = '⚠️ ' . $response['non_service_area'];
            }
            
            if (isset($response['blacklisted_consignee'])) {
                $warnings[] = '⚠️ Blacklisted Consignee: ' . $response['blacklisted_consignee'];
            }
            
            if (isset($response['bdmk_message'])) {
                $warnings[] = '⚠️ ' . $response['bdmk_message'];
            }
            
            if (isset($response['video'])) {
                if (is_array($response['video']) && count($response['video']) >= 2) {
                    $warnings[] = '📹 Video: <a href="' . $response['video'][0] . '" target="_blank">' . $response['video'][0] . '</a><br>' . $response['video'][1];
                }
            }
            
            if (!empty($warnings)) {
                $note .= "\n\n" . implode("\n\n", $warnings);
            }
            
            $order->add_order_note($note);
            
            // Update order status
            $order->update_status('trax-booked');
            
            Trax_Logger::log('Shipment booked successfully', $tracking_number);
            
            // Prepare return data
            $return_data = array(
                'success' => true,
                'message' => $response['message'],
                'tracking_number' => $tracking_number
            );
            
            // Add warnings to return data
            if (isset($response['non_service_area'])) {
                $return_data['non_service_area'] = $response['non_service_area'];
            }
            
            if (isset($response['blacklisted_consignee'])) {
                $return_data['blacklisted_consignee'] = $response['blacklisted_consignee'];
            }
            
            if (isset($response['bdmk_message'])) {
                $return_data['bdmk_message'] = $response['bdmk_message'];
            }
            
            if (isset($response['video'])) {
                $return_data['video'] = $response['video'];
            }
            
            return $return_data;
        } else {
            // Error
            $error_message = '';
            if (isset($response['errors'])) {
                foreach ($response['errors'] as $field => $errors) {
                    $error_message .= implode(', ', $errors) . ' ';
                }
            } else {
                $error_message = $response['message'] ?? 'Unknown error';
            }
            
            Trax_Logger::log('Booking failed', $error_message);
            
            return array('success' => false, 'message' => $error_message);
        }
    }
}
