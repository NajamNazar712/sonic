<?php
/**
 * Trax API Class
 * 
 * @package TraxLogistics
 */

defined('ABSPATH') or die('No direct script access allowed!');

class Trax_API {
    
    private $api_key;
    private $base_url;
    
    public function __construct() {
        $this->api_key  = get_option('trax_api_key');
        $saved_url      = get_option('trax_base_url', '');
        $this->base_url = !empty(trim($saved_url)) ? rtrim(trim($saved_url), '/') . '/' : 'https://sonic.pk/';
    }
    
    /**
     * Make API request
     * 
     * @param string $endpoint
     * @param array $data
     * @param string $method
     * @return array|WP_Error
     */
    private function request($endpoint, $data = array(), $method = 'GET') {
        $url = $this->base_url . 'api/' . $endpoint;
        
        $args = array(
            'timeout' => 60,
            'sslverify' => false,
            'headers' => array(
                'Authorization' => $this->api_key,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json'
            )
        );
        
        Trax_Logger::log("API Request: {$method} {$url}", $data);
        
        if ($method === 'POST') {
            $args['body'] = wp_json_encode($data);
            $args['method'] = 'POST';
            $response = wp_remote_post($url, $args);
        } else {
            $response = wp_remote_get($url, $args);
        }
        
        if (is_wp_error($response)) {
            Trax_Logger::log('API Error', $response->get_error_message());
            return $response;
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        Trax_Logger::log("API Response HTTP {$http_code}", substr($body, 0, 500));
        
        $decoded = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            Trax_Logger::log('JSON Decode Error', json_last_error_msg());
            return new WP_Error('json_error', 'Failed to decode API response');
        }
        
        return $decoded;
    }
    
    /**
     * Get cities list
     * 
     * @return array|WP_Error
     */
    public function get_cities() {
        $response = $this->request('cities');
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (!isset($response['status']) || $response['status'] != 0) {
            return new WP_Error('api_error', $response['message'] ?? 'Failed to fetch cities');
        }
        
        $cities = array();
        foreach ($response['cities'] as $city) {
            $cities[] = array(
                'id' => $city['id'],
                'name' => $city['name']
            );
        }
        
        return $cities;
    }
    
    /**
     * Get pickup addresses
     * 
     * @return array|WP_Error
     */
    public function get_pickup_addresses() {
        $response = $this->request('pickup_addresses');
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (!isset($response['status']) || $response['status'] != 0) {
            return new WP_Error('api_error', $response['message'] ?? 'Failed to fetch pickup addresses');
        }
        
        $addresses = array();
        foreach ($response['pickup_addresses'] as $address) {
            if ($address['status']) {
                $addresses[] = array(
                    'id'      => $address['id'],
                    'address' => $address['address'] . ', ' . $address['city']['name'],
                    'city_id' => $address['city']['id'],
                    'city_name' => $address['city']['name'],
                );
            }
        }
        
        return $addresses;
    }
    
    /**
     * Book shipment
     * 
     * @param array $data
     * @return array|WP_Error
     */
    public function book_shipment($data) {
        $response = $this->request('shipment/book', $data, 'POST');
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $response;
    }
    
    /**
     * Get airway bill
     * 
     * @param string|array $tracking_numbers
     * @return array|WP_Error
     */
    public function get_airway_bill($tracking_numbers) {
        $data = array();
        
        if (is_array($tracking_numbers)) {
            $data['tracking_numbers'] = $tracking_numbers;
        } else {
            $data['tracking_number'] = $tracking_numbers;
        }
        
        $response = $this->request('shipment/air_waybill', $data, 'POST');
        
        return $response;
    }
    
    /**
     * Validate consignee before booking
     */
    public function validate_consignee($data) {
        return $this->request('shipment/validate', $data, 'POST');
    }
    
    /**
     * Cancel shipment
     */
    public function cancel_shipment($tracking_number) {
        $response = $this->request('shipment/cancel', array(
            'tracking_number' => $tracking_number
        ), 'POST');
        
        return $response;
    }
    
    /**
     * Track shipment
     * 
     * @param string $tracking_number
     * @return array|WP_Error
     */
    public function track_shipment($tracking_number) {
        $response = $this->request('tracking?tracking_number=' . $tracking_number);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $response;
    }
}
