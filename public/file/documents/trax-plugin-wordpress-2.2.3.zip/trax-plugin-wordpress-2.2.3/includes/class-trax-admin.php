<?php
/**
 * Trax Admin Class
 * 
 * @package TraxLogistics
 */

defined('ABSPATH') or die('No direct script access allowed!');

class Trax_Admin {
    
    public function __construct() {
        // Add settings page
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Add meta box to order page
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        
        // Add bulk action
        add_filter('bulk_actions-edit-shop_order', array($this, 'add_bulk_action'));
        add_filter('bulk_actions-woocommerce_page_wc-orders', array($this, 'add_bulk_action'));
        
        // Handle bulk action
        add_filter('handle_bulk_actions-edit-shop_order', array($this, 'handle_bulk_action'), 10, 3);
        add_filter('handle_bulk_actions-woocommerce_page_wc-orders', array($this, 'handle_bulk_action'), 10, 3);
        
        // Add tracking column - REMOVED, we inject into existing tracking column instead
        // add_filter('manage_edit-shop_order_columns', array($this, 'add_tracking_column'));
        // add_action('manage_shop_order_posts_custom_column', array($this, 'tracking_column_content'));
        
        // Add tracking column for HPOS - REMOVED
        // add_filter('manage_woocommerce_page_wc-orders_columns', array($this, 'add_tracking_column'));
        // add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'tracking_column_content_hpos'), 10, 2);
        
        // Inject Trax tracking into existing tracking column (legacy)
        add_action('manage_shop_order_posts_custom_column', array($this, 'tracking_column_content'));
        
        // Inject Trax tracking into existing tracking column (HPOS)
        add_action('manage_woocommerce_page_wc-orders_custom_column', array($this, 'tracking_column_content_hpos'), 10, 2);
        
        // AJAX handlers
        add_action('wp_ajax_trax_get_order_data', array($this, 'ajax_get_order_data'));
        add_action('wp_ajax_trax_book_shipment', array($this, 'ajax_book_shipment'));
        add_action('wp_ajax_trax_bulk_check_orders', array($this, 'ajax_bulk_check_orders'));
        add_action('wp_ajax_trax_download_airway_bill', array($this, 'ajax_download_airway_bill'));
        add_action('wp_ajax_trax_fetch_pickup_addresses', array($this, 'ajax_fetch_pickup_addresses'));
        add_action('wp_ajax_trax_cancel_shipment', array($this, 'ajax_cancel_shipment'));
        add_action('wp_ajax_trax_validate_consignee', array($this, 'ajax_validate_consignee'));
        
        // Add order status
        add_filter('wc_order_statuses', array('Trax_Booking', 'add_order_status'));
        
        // Add modal HTML to footer
        add_action('admin_footer', array($this, 'add_modal_html'));
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_scripts($hook) {
        // Load on settings page
        if ($hook === 'settings_page_trax-settings') {
            wp_enqueue_script('jquery');
            wp_localize_script('jquery', 'traxVars', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('trax_nonce')
            ));
            return;
        }
        
        // Only load on order pages
        if ($hook !== 'post.php' && $hook !== 'edit.php' && $hook !== 'woocommerce_page_wc-orders') {
            return;
        }
        
        $screen = get_current_screen();
        if ($screen && $screen->post_type !== 'shop_order' && $screen->id !== 'woocommerce_page_wc-orders') {
            return;
        }
        
        // Enqueue styles
        wp_enqueue_style('trax-admin', TRAX_PLUGIN_URL . 'assets/css/admin.css', array(), TRAX_VERSION);
        wp_enqueue_style('woocommerce_admin_styles'); // includes select2
        
        // Enqueue scripts
        wp_enqueue_script('selectWoo'); // WooCommerce's select2 fork
        wp_enqueue_script('trax-admin', TRAX_PLUGIN_URL . 'assets/js/admin.js', array('jquery', 'selectWoo'), TRAX_VERSION, true);
        
        // Localize script
        wp_localize_script('trax-admin', 'traxVars', array(
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('trax_nonce'),
            'pluginUrl' => TRAX_PLUGIN_URL,
        ));
    }
    
    /**
     * Add settings page
     */
    public function add_settings_page() {
        add_options_page(
            'Trax Logistics Settings',
            'Trax Logistics',
            'manage_options',
            'trax-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('trax_settings', 'trax_api_key');
        register_setting('trax_settings', 'trax_base_url');
        register_setting('trax_settings', 'trax_pickup_address_id');
        register_setting('trax_settings', 'trax_default_shipping_mode');
        register_setting('trax_settings', 'trax_enable_debug');
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        $error_message = null;
        $pickup_addresses = array();
        
        // Only fetch addresses if API key is set
        $api_key = get_option('trax_api_key');
        if (!empty($api_key)) {
            $api = new Trax_API();
            $result = $api->get_pickup_addresses();
            
            if (is_wp_error($result)) {
                $error_message = $result->get_error_message();
            } else {
                $pickup_addresses = $result;
            }
        } else {
            $error_message = 'Please enter your API key first, then save to load pickup addresses';
        }
        
        include TRAX_PLUGIN_DIR . 'templates/settings-page.php';
    }
    
    /**
     * Add meta box to order page
     */
    public function add_meta_box() {
        // Add to sidebar (side)
        add_meta_box(
            'trax-details-side',
            __('Trax Details', 'trax-logistics'),
            array($this, 'render_meta_box'),
            'shop_order',
            'side',
            'high'
        );
        
        add_meta_box(
            'trax-details-side',
            __('Trax Details', 'trax-logistics'),
            array($this, 'render_meta_box'),
            'woocommerce_page_wc-orders',
            'side',
            'high'
        );
        
        // Also add to normal area (below Leopard Details)
        add_meta_box(
            'trax-details-normal',
            __('Trax Logistics Booking', 'trax-logistics'),
            array($this, 'render_meta_box_normal'),
            'shop_order',
            'normal',
            'default'
        );
        
        add_meta_box(
            'trax-details-normal',
            __('Trax Logistics Booking', 'trax-logistics'),
            array($this, 'render_meta_box_normal'),
            'woocommerce_page_wc-orders',
            'normal',
            'default'
        );
    }
    
    /**
     * Render meta box
     */
    public function render_meta_box($post_or_order) {
        $order = $post_or_order instanceof WP_Post ? wc_get_order($post_or_order->ID) : $post_or_order;
        
        if (!$order) {
            return;
        }
        
        $tracking_number = $order->get_meta('_trax_tracking_number');
        
        include TRAX_PLUGIN_DIR . 'templates/meta-box.php';
    }
    
    /**
     * Render normal meta box (larger, below Leopard)
     */
    public function render_meta_box_normal($post_or_order) {
        $order = $post_or_order instanceof WP_Post ? wc_get_order($post_or_order->ID) : $post_or_order;
        
        if (!$order) {
            return;
        }
        
        $tracking_number = $order->get_meta('_trax_tracking_number');
        
        include TRAX_PLUGIN_DIR . 'templates/meta-box-normal.php';
    }
    
    /**
     * Add bulk action
     */
    public function add_bulk_action($bulk_actions) {
        $bulk_actions['trax_bulk_shipment'] = __('Book at Trax', 'trax-logistics');
        return $bulk_actions;
    }
    
    /**
     * Handle bulk action
     */
    public function handle_bulk_action($redirect_to, $action, $post_ids) {
        if ($action !== 'trax_bulk_shipment') {
            return $redirect_to;
        }
        
        // Don't redirect, let JavaScript handle it
        // The modal will be triggered by JavaScript detecting the bulk action
        return $redirect_to;
    }
    
    /**
     * Add tracking column
     */
    public function add_tracking_column($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'order_status') {
                $new_columns['trax_tracking'] = __('Trax Logistics', 'trax-logistics');
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Tracking column content - inject Trax tracking into LCS tracking column
     */
    public function tracking_column_content($column) {
        global $post;
        
        if ($column === 'lcs_tracking_number') {
            $order = wc_get_order($post->ID);
            if (!$order) return;
            
            $tracking_number = $order->get_meta('_trax_tracking_number');
            
            if ($tracking_number) {
                echo '<div class="trax-tracking-inline" style="margin-top:5px; padding-top:5px; border-top:1px dashed #ddd;">';
                echo '<a href="' . esc_url(trax_tracking_url($tracking_number)) . '" target="_blank" style="font-weight:600; color:#0073aa;">' . esc_html($tracking_number) . '</a>';
                echo ' <span style="font-size:10px; background:#0073aa; color:#fff; padding:1px 5px; border-radius:3px;">Trax</span>';
                echo '<br><a href="#" class="trax-download-airway-bill" data-tracking="' . esc_attr($tracking_number) . '" style="font-size:11px;">📄 Print AWB</a>';
                echo ' &nbsp; <a href="#" class="trax-cancel-shipment" data-tracking="' . esc_attr($tracking_number) . '" data-order-id="' . esc_attr($post->ID) . '" style="font-size:11px; color:#a00;">✕ Cancel</a>';
                echo '</div>';
            }
        }
    }
    
    /**
     * Tracking column content for HPOS - inject Trax tracking into LCS tracking column
     */
    public function tracking_column_content_hpos($column, $order) {
        if ($column === 'lcs_tracking_number') {
            if (is_numeric($order)) {
                $order = wc_get_order($order);
            }
            
            if (!$order) return;
            
            $tracking_number = $order->get_meta('_trax_tracking_number');
            
            if ($tracking_number) {
                echo '<div class="trax-tracking-inline" style="margin-top:5px; padding-top:5px; border-top:1px dashed #ddd;">';
                echo '<a href="' . esc_url(trax_tracking_url($tracking_number)) . '" target="_blank" style="font-weight:600; color:#0073aa;">' . esc_html($tracking_number) . '</a>';
                echo ' <span style="font-size:10px; background:#0073aa; color:#fff; padding:1px 5px; border-radius:3px;">Trax</span>';
                echo '<br><a href="#" class="trax-download-airway-bill" data-tracking="' . esc_attr($tracking_number) . '" style="font-size:11px;">📄 Print AWB</a>';
                echo ' &nbsp; <a href="#" class="trax-cancel-shipment" data-tracking="' . esc_attr($tracking_number) . '" data-order-id="' . esc_attr($order->get_id()) . '" style="font-size:11px; color:#a00;">✕ Cancel</a>';
                echo '</div>';
            }
        }
    }
    
    /**
     * AJAX: Get order data
     */
    public function ajax_get_order_data() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        
        if (!$order_id) {
            wp_send_json_error(array('message' => 'Invalid order ID'));
        }
        
        $order_data = Trax_Booking::get_order_booking_data($order_id);
        
        if (!$order_data) {
            wp_send_json_error(array('message' => 'Order not found'));
        }
        
        // Get cities
        $api = new Trax_API();
        $cities = $api->get_cities();
        
        if (is_wp_error($cities)) {
            wp_send_json_error(array('message' => $cities->get_error_message()));
        }
        
        wp_send_json_success(array(
            'order_data' => $order_data,
            'cities' => $cities
        ));
    }
    
    /**
     * AJAX: Book shipment
     */
    public function ajax_book_shipment() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $order_id     = isset($_POST['order_id'])     ? intval($_POST['order_id'])     : 0;
        $booking_data = isset($_POST['booking_data']) ? wp_unslash($_POST['booking_data']) : array();
        
        if (!$order_id) {
            wp_send_json_error(array('message' => 'Invalid order ID'));
        }
        
        // Sanitize all booking_data fields explicitly
        $clean = array(
            'consignee_city_id'    => isset($booking_data['consignee_city_id'])    ? intval($booking_data['consignee_city_id'])                    : 0,
            'shipping_mode_id'     => isset($booking_data['shipping_mode_id'])     ? intval($booking_data['shipping_mode_id'])                     : 1,
            'consignee_name'       => isset($booking_data['consignee_name'])       ? sanitize_text_field($booking_data['consignee_name'])          : '',
            'consignee_address'    => isset($booking_data['consignee_address'])    ? sanitize_textarea_field($booking_data['consignee_address'])   : '',
            'consignee_phone'      => isset($booking_data['consignee_phone'])      ? sanitize_text_field($booking_data['consignee_phone'])         : '',
            'consignee_email'      => isset($booking_data['consignee_email'])      ? sanitize_email($booking_data['consignee_email'])              : '',
            'amount'               => isset($booking_data['amount'])               ? (string) $booking_data['amount']                             : '0',
            'parcel_value'         => isset($booking_data['parcel_value'])         ? (string) $booking_data['parcel_value']                       : '0',
            'item_description'     => isset($booking_data['item_description'])     ? sanitize_textarea_field($booking_data['item_description'])   : '',
            'item_quantity'        => isset($booking_data['item_quantity'])        ? intval($booking_data['item_quantity'])                        : 1,
            'estimated_weight'     => isset($booking_data['estimated_weight'])     ? (string) $booking_data['estimated_weight']                   : '1',
            'special_instructions' => isset($booking_data['special_instructions']) ? sanitize_text_field($booking_data['special_instructions'])   : '',
        );
        
        Trax_Logger::log('Booking AJAX received - amount', $clean['amount']);
        Trax_Logger::log('Booking AJAX received - parcel_value', $clean['parcel_value']);
        Trax_Logger::log('Booking AJAX received - estimated_weight', $clean['estimated_weight']);
        
        $result = Trax_Booking::book_shipment($order_id, $clean);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX: Bulk check orders
     */
    public function ajax_bulk_check_orders() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $order_ids = isset($_POST['order_ids']) ? array_map('intval', $_POST['order_ids']) : array();
        
        if (empty($order_ids)) {
            wp_send_json_error(array('message' => 'No orders selected'));
        }
        
        // Get cities
        $api = new Trax_API();
        $cities = $api->get_cities();
        
        if (is_wp_error($cities)) {
            wp_send_json_error(array('message' => $cities->get_error_message()));
        }
        
        $orders_data = array();
        
        foreach ($order_ids as $order_id) {
            $order_data = Trax_Booking::get_order_booking_data($order_id);
            
            if ($order_data) {
                $order = wc_get_order($order_id);
                $tracking_number = $order->get_meta('_trax_tracking_number');
                
                $order_data['is_booked'] = !empty($tracking_number);
                $order_data['tracking_number'] = $tracking_number;
                
                $orders_data[] = $order_data;
            }
        }
        
        wp_send_json_success(array(
            'orders' => $orders_data,
            'cities' => $cities
        ));
    }
    
    /**
     * AJAX: Download airway bill
     */
    public function ajax_download_airway_bill() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $tracking_number = isset($_POST['tracking_number']) ? sanitize_text_field($_POST['tracking_number']) : '';
        
        if (empty($tracking_number)) {
            wp_send_json_error(array('message' => 'Invalid tracking number'));
        }
        
        $api_key  = get_option('trax_api_key');
        $base_url = get_option('trax_base_url', '');
        $base_url = !empty(trim($base_url)) ? rtrim(trim($base_url), '/') . '/' : 'https://sonic.pk/';
        
        // Build the AWB URL - type=1 for PDF
        $awb_url = $base_url . 'api/shipment/air_waybill?tracking_number=' . urlencode($tracking_number) . '&type=1';
        
        // We can't proxy binary files easily through AJAX, so we build a URL
        // that the browser can open directly. Since it requires Authorization header,
        // we use the AJAX endpoint to generate a temporary redirect URL.
        // Best approach: open the URL via a form POST or direct link with token in query.
        // The API uses Authorization header (not Bearer), so we pass it as a query param workaround.
        // Instead, proxy the file through WordPress AJAX.
        
        $response = wp_remote_get($awb_url, array(
            'headers' => array(
                'Authorization' => $api_key,
                'Accept'        => 'application/json',
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }
        
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        $body = wp_remote_retrieve_body($response);
        $http_code = wp_remote_retrieve_response_code($response);
        
        // Check if it's a JSON error response
        if (strpos($content_type, 'application/json') !== false || $http_code !== 200) {
            $json = json_decode($body, true);
            $message = isset($json['message']) ? $json['message'] : 'Failed to get AWB';
            wp_send_json_error(array('message' => $message));
        }
        
        // It's a binary file - encode as base64 and send back
        $base64 = base64_encode($body);
        $is_pdf = strpos($content_type, 'pdf') !== false;
        $mime = $is_pdf ? 'application/pdf' : 'image/jpeg';
        $ext  = $is_pdf ? 'pdf' : 'jpg';
        
        wp_send_json_success(array(
            'base64'   => $base64,
            'mime'     => $mime,
            'filename' => 'AWB_' . $tracking_number . '.' . $ext,
        ));
    }
    
    /**
     * AJAX: Fetch pickup addresses
     */
    public function ajax_fetch_pickup_addresses() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'API key is required'));
        }
        
        // Temporarily set the API key
        $old_key = get_option('trax_api_key');
        update_option('trax_api_key', $api_key);
        
        $api = new Trax_API();
        $addresses = $api->get_pickup_addresses();
        
        // Restore old key
        update_option('trax_api_key', $old_key);
        
        if (is_wp_error($addresses)) {
            wp_send_json_error(array('message' => $addresses->get_error_message()));
        }
        
        wp_send_json_success(array('addresses' => $addresses));
    }
    
    /**
     * AJAX: Cancel shipment
     */
    public function ajax_cancel_shipment() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $tracking_number = isset($_POST['tracking_number']) ? sanitize_text_field($_POST['tracking_number']) : '';
        $order_id        = isset($_POST['order_id'])        ? intval($_POST['order_id'])                     : 0;
        
        if (empty($tracking_number)) {
            wp_send_json_error(array('message' => 'Invalid tracking number'));
        }
        
        $api      = new Trax_API();
        $response = $api->cancel_shipment($tracking_number);
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }
        
        if (isset($response['status']) && $response['status'] == 0) {
            // Update order meta and add note
            if ($order_id) {
                $order = wc_get_order($order_id);
                if ($order) {
                    $order->delete_meta_data('_trax_tracking_number');
                    $order->delete_meta_data('_trax_booked_by');
                    $order->save();
                    $order->add_order_note('Trax shipment cancelled. Tracking: ' . $tracking_number);
                }
            }
            wp_send_json_success(array('message' => $response['message']));
        } else {
            wp_send_json_error(array('message' => $response['message'] ?? 'Failed to cancel shipment'));
        }
    }
    /**
     * AJAX: Validate consignee
     */
    public function ajax_validate_consignee() {
        check_ajax_referer('trax_nonce', 'nonce');
        
        $data = isset($_POST['validate_data']) ? wp_unslash($_POST['validate_data']) : array();
        
        $payload = array(
            'consignee_city_id'       => isset($data['consignee_city_id'])       ? intval($data['consignee_city_id'])                  : 0,
            'consignee_name'          => isset($data['consignee_name'])          ? sanitize_text_field($data['consignee_name'])         : '',
            'consignee_address'       => isset($data['consignee_address'])       ? sanitize_textarea_field($data['consignee_address'])  : '',
            'consignee_phone_number_1'=> isset($data['consignee_phone'])         ? sanitize_text_field($data['consignee_phone'])        : '',
        );
        
        $api      = new Trax_API();
        $response = $api->validate_consignee($payload);
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }
        
        // status 1 = validation error, status 0 = ok (with or without warnings)
        if (isset($response['status']) && $response['status'] == 1) {
            wp_send_json_error(array('message' => $response['message']));
        }
        
        // Return warnings if any
        $result = array('message' => $response['message'] ?? 'Validated');
        foreach (['non_service_area', 'blacklisted_consignee', 'bdmk_message'] as $key) {
            if (!empty($response[$key])) {
                $result[$key] = $response[$key];
            }
        }
        
        wp_send_json_success($result);
    }
    
    /**
     * Add modal HTML to footer
     */
    public function add_modal_html() {
        $screen = get_current_screen();
        
        if (!$screen || ($screen->post_type !== 'shop_order' && $screen->id !== 'woocommerce_page_wc-orders')) {
            return;
        }
        
        include TRAX_PLUGIN_DIR . 'templates/modal-single.php';
        include TRAX_PLUGIN_DIR . 'templates/modal-bulk.php';
    }
}
