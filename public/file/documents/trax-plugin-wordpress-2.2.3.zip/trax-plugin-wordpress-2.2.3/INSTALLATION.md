# Trax Logistics Plugin v2.2.3 - Installation Guide

## Prerequisites
- WordPress 5.8 or higher
- WooCommerce 6.0 or higher
- PHP 7.4 or higher
- Valid Trax Sonic API key

## Installation Steps

### Step 1: Backup Current Plugin
1. Go to WordPress admin → Plugins
2. Find "Trax Logistics" (v2.2.1)
3. **Do NOT deactivate yet** - your settings will be preserved

### Step 2: Upload New Plugin
1. Download `trax-logistics-v2.2.3.zip`
2. Go to WordPress admin → Plugins → Add New
3. Click "Upload Plugin"
4. Choose the zip file and click "Install Now"
5. **Do NOT activate yet**

### Step 3: Deactivate Old Plugin
1. Go to Plugins → Installed Plugins
2. Find "Trax Logistics" (v2.2.1)
3. Click "Deactivate"
4. **Do NOT delete** - keep as backup

### Step 4: Activate New Plugin
1. Find "Trax Logistics" (v2.2.3)
2. Click "Activate"
3. You should see a success message

### Step 5: Verify Settings
1. Go to WooCommerce → Settings → Trax Logistics
2. Verify your API key is still there
3. Verify your Pickup Address is selected
4. Save settings if needed

### Step 6: Test Booking
1. Go to WooCommerce → Orders
2. Open any order
3. Look for "Trax Details" meta box
4. Click "Create Shipment"
5. Modal should open with pre-filled data

## Troubleshooting

### Modal doesn't open
- Clear browser cache
- Check browser console for JavaScript errors
- Verify jQuery is loaded

### API errors
- Verify API key in settings
- Check debug log: `wp-content/uploads/trax-debug.log`
- Ensure server can reach `sonic.pk`

### Tracking numbers not showing
- Check if orders have `tracking_number` meta
- Verify column is enabled in Screen Options

### Plugin conflicts
If you experience issues, deactivate these plugins temporarily:
- Google for WooCommerce
- Print Invoices Packing Slip Labels for WooCommerce

## Rollback to v2.2.1
If you need to rollback:
1. Deactivate v2.2.3
2. Activate v2.2.1 (still in your plugins folder)
3. Your data will be intact

## Support
For issues, check the debug log first:
```
wp-content/uploads/trax-debug.log
```

Contact Trax support with:
- WordPress version
- WooCommerce version
- PHP version
- Error messages from debug log
