# Trax Logistics Plugin v2.2.3 - Requirements

## Overview
Complete rewrite of Trax booking plugin with modern UI similar to Leopards Courier System (LCS).

## Core Features

### 1. Single Order Booking
- **Location**: Order detail page → Meta box "Trax Details"
- **Button**: "Create Shipment" (blue button)
- **Flow**: 
  1. Click "Create Shipment" → Opens modal popup
  2. Fill booking form (pre-populated from order data)
  3. Click "Preview" → Shows confirmation screen
  4. Click "Submit" → Books shipment via API
  5. Success → Shows tracking number, updates order status to "Booked at Trax"

### 2. Bulk Order Booking
- **Location**: Orders list page → Bulk actions dropdown
- **Action**: "Book at Trax"
- **Flow**:
  1. Select multiple orders → Choose "Book at Trax" → Apply
  2. Opens modal popup with table of all selected orders
  3. Edit fields per order (city, shipping mode, weight, etc.)
  4. Click "Create Bulk Shipment" → Books all via API
  5. Success → Shows results for each order

### 3. Tracking Number Display
- **Location**: Orders list page → New column "Trax Logistics"
- **Display**: 
  - Clickable tracking number (e.g., "MX7531170558")
  - Icon for print airway bill
  - Opens tracking page: `https://sonic.pk/tracking?tracking_number=XXX`

### 4. Airway Bill Generation
- **API Endpoint**: POST `/api/shipment/air_waybill`
- **Required Fields**:
  - `tracking_number` (single) OR `tracking_numbers` (array, max 5)
  - Authorization token in header
- **Action**: Download PDF airway bill
- **Location**: 
  - Order detail page → Print icon next to tracking number
  - Orders list page → Print icon in Trax column

## API Integration

### Booking API
- **Endpoint**: `https://sonic.pk/api/shipment/book`
- **Method**: POST
- **Headers**: 
  - `Authorization: {API_KEY}`
  - `Accept: application/json`
- **Required Fields**:
  - order_id
  - service_type_id (always 1)
  - shipping_mode_id (1=Rush, 2=Saver Plus, 3=Swift)
  - pickup_address_id
  - consignee_city_id
  - consignee_name
  - consignee_address
  - consignee_phone_number_1
  - consignee_email_address (optional)
  - item_product_type_id (always 24)
  - item_description
  - item_quantity
  - estimated_weight
  - amount (COD amount, 0 for prepaid)
  - parcel_value
  - pickup_date (Y-m-d format)
  - special_instructions (optional)

### Airway Bill API
- **Endpoint**: `https://sonic.pk/api/shipment/air_waybill`
- **Method**: POST
- **Headers**: 
  - `Authorization: {API_KEY}`
  - `Accept: application/json`
- **Required Fields**:
  - `tracking_number` (single integer, 10-20 digits) OR
  - `tracking_numbers` (array of integers, min 1, max 5)
- **Response**: PDF file download

### Cities API
- **Endpoint**: `https://sonic.pk/api/cities`
- **Method**: GET
- **Headers**: 
  - `Authorization: {API_KEY}`
  - `Accept: application/json`

## UI/UX Requirements

### Modal Design
- **Style**: Bootstrap-based modal (similar to LCS screenshots)
- **Width**: 800px for single, 1200px for bulk
- **Sections**:
  - Header with title and close button
  - Form fields in clean layout
  - Footer with action buttons (Preview, Submit, Back, Cancel)

### Form Fields (Single Booking)
1. Destination City (dropdown, searchable)
2. Shipment Type (dropdown: Rush, Saver Plus, Swift)
3. Shipper (text, pre-filled from settings)
4. Actual Price (number, pre-filled from order total)
5. Actual Piece (number, default 1)
6. Customer City (text, pre-filled)
7. Packet Weight (number, calculated from products)
8. Shipment Address (textarea, pre-filled)
9. Shipment Email (email, pre-filled)
10. Shipment Name (text, pre-filled)
11. Shipment Phone (text, pre-filled)
12. Special Instructions (textarea, optional)
13. Items (readonly list, formatted)

### Bulk Booking Table Columns
1. Order # (with hidden input)
2. Shipping Mode (dropdown)
3. Consignee Name (text input)
4. Consignee Address (textarea)
5. Consignee Phone (text input)
6. City (dropdown)
7. COD Amount (number input)
8. Item Description (textarea)
9. Item Quantity (number input)
10. Item Weight (number input)
11. Special Instructions (textarea)
12. Action (Remove button)

### Order Status
- **New Status**: "Booked at Trax" (`wc-trax-booked`)
- **Auto-update**: After successful booking
- **Order Note**: Add note with tracking number and link

## File Structure

```
trax-plugin-v2.2.3/
├── trax-logistics.php          # Main plugin file
├── README.md                    # Installation guide
├── REQUIREMENTS.md              # This file
├── assets/
│   ├── css/
│   │   └── admin.css           # Admin styles
│   ├── js/
│   │   ├── booking-modal.js    # Modal functionality
│   │   └── bulk-booking.js     # Bulk booking logic
│   └── images/
│       ├── icon-128x128.png
│       └── icon-256x256.png
├── includes/
│   ├── class-trax-api.php      # API wrapper
│   ├── class-trax-booking.php  # Booking logic
│   ├── class-trax-admin.php    # Admin UI
│   └── class-trax-logger.php   # Debug logging
└── templates/
    ├── modal-single-booking.php
    ├── modal-bulk-booking.php
    └── meta-box-order-details.php
```

## Settings Page
- **Location**: WooCommerce → Settings → Trax Logistics
- **Fields**:
  1. API Key (text, required)
  2. Pickup Address (dropdown, fetched from API)
  3. Default Shipping Mode (dropdown)
  4. Enable Debug Logging (checkbox)

## Compatibility
- **WordPress**: 5.8+
- **WooCommerce**: 6.0+
- **PHP**: 7.4+
- **HPOS**: Full support (use `wc_get_order()`)

## Migration from v2.2.1
- Preserve existing order meta (tracking_number, booked_by)
- No data loss
- Deactivate old plugin before activating new one

## Testing Checklist
- [ ] Single order booking works
- [ ] Bulk order booking works
- [ ] Preview screen shows correct data
- [ ] Tracking numbers are clickable
- [ ] Airway bill downloads correctly
- [ ] Order status updates properly
- [ ] Works with HPOS enabled
- [ ] No conflicts with Google/Print plugins
- [ ] Debug logging works
- [ ] Settings page saves correctly
