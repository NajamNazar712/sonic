# Trax Plugin v2.2.3 - Deployment Guide

## What's Been Built

A complete rewrite of the Trax Logistics plugin with modern UI inspired by Leopards Courier System.

### Key Features
1. **Modal-based booking** - Clean popup interface (no more full-page redirects)
2. **Preview before submit** - Review all details before booking
3. **Bulk booking** - Book multiple orders at once with city matching
4. **Clickable tracking** - Tracking numbers link directly to tracking page
5. **Airway bill download** - One-click PDF download
6. **HPOS compatible** - Uses `wc_get_order()` throughout
7. **No conflicts** - Isolated from Google/Print plugins

## File Structure

```
trax-plugin-v2.2.3/
├── trax-logistics.php              # Main plugin file
├── README.md                        # User documentation
├── REQUIREMENTS.md                  # Technical requirements
├── INSTALLATION.md                  # Installation guide
├── DEPLOYMENT-GUIDE.md              # This file
├── includes/
│   ├── class-trax-logger.php       # Debug logging
│   ├── class-trax-api.php          # API wrapper
│   ├── class-trax-admin.php        # Admin interface
│   └── class-trax-booking.php      # Booking logic
├── templates/
│   ├── settings-page.php           # Settings page
│   ├── meta-box.php                # Order detail meta box
│   ├── modal-single.php            # Single booking modal
│   └── modal-bulk.php              # Bulk booking modal
└── assets/
    ├── css/
    │   └── admin.css               # Admin styles
    ├── js/
    │   └── admin.js                # Admin JavaScript
    └── images/
        ├── icon-128x128.png        # Plugin icon (copy from old plugin)
        └── icon-256x256.png        # Plugin icon (copy from old plugin)
```

## Deployment Steps

### 1. Prepare Plugin Package

```bash
# On your local machine
cd trax-plugin-v2.2.3

# Copy icons from old plugin
cp ../assets/*.png assets/images/

# Create zip file
zip -r trax-logistics-v2.2.3.zip . -x "*.git*" -x "*.DS_Store"
```

### 2. Backup Current Plugin

On the live server:
```bash
cd /var/www/mywordpress.sonic.pk/public/wp-content/plugins
cp -r trax-plugin-wordpress-2.2.2 trax-plugin-wordpress-2.2.2-backup
```

### 3. Upload New Plugin

Option A: Via WordPress Admin
1. Go to Plugins → Add New → Upload Plugin
2. Choose `trax-logistics-v2.2.3.zip`
3. Click "Install Now"
4. **Do NOT activate yet**

Option B: Via SSH/FTP
```bash
# Upload zip to server
scp trax-logistics-v2.2.3.zip user@server:/tmp/

# On server
cd /var/www/mywordpress.sonic.pk/public/wp-content/plugins
unzip /tmp/trax-logistics-v2.2.3.zip -d trax-logistics
```

### 4. Switch Plugins

1. Go to WordPress Admin → Plugins
2. **Deactivate** "Trax Logistics" (v2.2.1)
3. **Activate** "Trax Logistics" (v2.2.3)

### 5. Configure Settings

1. Go to Settings → Trax Logistics
2. Verify API key is still there (should be preserved)
3. Verify Pickup Address is selected
4. Enable Debug Logging (recommended for first few days)
5. Click "Save Changes"

### 6. Test Single Booking

1. Go to WooCommerce → Orders
2. Open any order
3. Look for "Trax Details" meta box in sidebar
4. Click "Create Shipment"
5. Modal should open with pre-filled data
6. Click "Preview"
7. Click "Submit"
8. Verify tracking number appears

### 7. Test Bulk Booking

1. Go to WooCommerce → Orders
2. Select 2-3 orders (checkbox)
3. Choose "Book at Trax" from Bulk Actions
4. Click "Apply"
5. Modal should open with table of orders
6. Verify cities are matched
7. Click "Create Bulk Shipment"
8. Wait for all orders to process

### 8. Test Tracking

1. Go to WooCommerce → Orders
2. Find order with tracking number in "Trax Logistics" column
3. Click tracking number → Should open tracking page
4. Click "Download AWB" → Should download PDF

### 9. Monitor Logs

```bash
# Watch debug log
tail -f /var/www/mywordpress.sonic.pk/public/wp-content/uploads/trax-debug.log

# Watch PHP error log
tail -f /var/www/mywordpress.sonic.pk/public/wp-content/debug.log
```

## Troubleshooting

### Modal doesn't open
- Check browser console for JavaScript errors
- Verify jQuery is loaded
- Clear browser cache

### API errors
- Check debug log: `wp-content/uploads/trax-debug.log`
- Verify API key in settings
- Test API manually: `curl -H "Authorization: YOUR_API_KEY" https://sonic.pk/api/cities`

### Cities not loading
- Check if API key is valid
- Check if server can reach sonic.pk
- Look for errors in debug log

### Bulk booking fails
- Check if orders have valid cities
- Verify pickup address is set
- Check debug log for specific errors

### Plugin conflicts
If issues persist, temporarily deactivate:
- Google for WooCommerce
- Print Invoices Packing Slip Labels

## Rollback Plan

If something goes wrong:

```bash
# Via WordPress Admin
1. Deactivate v2.2.3
2. Activate v2.2.1 (still in plugins folder)

# Via SSH
cd /var/www/mywordpress.sonic.pk/public/wp-content/plugins
mv trax-logistics trax-logistics-v2.2.3-disabled
mv trax-plugin-wordpress-2.2.2-backup trax-plugin-wordpress-2.2.2
```

## Post-Deployment

### Day 1-3
- Monitor debug log closely
- Test with real orders
- Collect user feedback

### After 1 Week
- If stable, disable debug logging
- Delete old plugin backup
- Update documentation

### After 1 Month
- Review performance
- Plan next features
- Update if needed

## Support Checklist

When reporting issues, provide:
- [ ] WordPress version
- [ ] WooCommerce version
- [ ] PHP version
- [ ] Active plugins list
- [ ] Debug log excerpt
- [ ] Steps to reproduce
- [ ] Screenshots/screen recording

## Next Steps

After successful deployment:
1. Train staff on new UI
2. Update internal documentation
3. Monitor for 1-2 weeks
4. Collect feedback
5. Plan v2.2.4 improvements

## Contact

For technical support:
- Check debug log first
- Review REQUIREMENTS.md
- Contact Trax support with log details
