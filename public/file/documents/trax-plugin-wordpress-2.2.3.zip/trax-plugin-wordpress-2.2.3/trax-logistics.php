<?php
/**
 * Plugin Name: Trax Logistics
 * Plugin URI: https://trax.pk
 * Description: Trax Sonic Shipment Booking Plugin with modern UI - Book shipments, track consignments, and download airway bills directly from WordPress.
 * Version: 2.2.3
 * Author: Trax Logistics
 * Author URI: https://trax.pk
 * License: GPLv2 or later
 * Text Domain: trax-logistics
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.5
 */

defined('ABSPATH') or die('No direct script access allowed!');

// Plugin constants
define('TRAX_VERSION', '2.2.3');
define('TRAX_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TRAX_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TRAX_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', 'trax_woocommerce_missing_notice');
    return;
}

function trax_woocommerce_missing_notice() {
    echo '<div class="error"><p><strong>Trax Logistics</strong> requires WooCommerce to be installed and active.</p></div>';
}

// Include required files
require_once TRAX_PLUGIN_DIR . 'includes/class-trax-logger.php';
require_once TRAX_PLUGIN_DIR . 'includes/class-trax-api.php';
require_once TRAX_PLUGIN_DIR . 'includes/class-trax-admin.php';
require_once TRAX_PLUGIN_DIR . 'includes/class-trax-booking.php';

// Declare HPOS compatibility early (before plugins_loaded)
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

// Initialize plugin
function trax_init() {
    // Register custom order status
    Trax_Booking::register_order_status();
    
    // Initialize admin interface
    if (is_admin()) {
        new Trax_Admin();
    }
}
add_action('plugins_loaded', 'trax_init');

// Activation hook
register_activation_hook(__FILE__, 'trax_activate');
function trax_activate() {
    // Set default options
    add_option('trax_api_key', '');
    add_option('trax_base_url', 'https://sonic.pk/');
    add_option('trax_pickup_address_id', '');
    add_option('trax_default_shipping_mode', '1');
    add_option('trax_enable_debug', 'no');
    add_option('trax_version', TRAX_VERSION);
    
    // Flush rewrite rules
    flush_rewrite_rules();
}

/**
 * Get the configured base URL (with trailing slash)
 */
function trax_base_url() {
    $url = get_option('trax_base_url', '');
    return !empty(trim($url)) ? rtrim(trim($url), '/') . '/' : 'https://sonic.pk/';
}

/**
 * Get the tracking URL for a given tracking number
 */
function trax_tracking_url($tracking_number) {
    return trax_base_url() . 'tracking?tracking_number=' . urlencode($tracking_number);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'trax_deactivate');
function trax_deactivate() {
    flush_rewrite_rules();
}
