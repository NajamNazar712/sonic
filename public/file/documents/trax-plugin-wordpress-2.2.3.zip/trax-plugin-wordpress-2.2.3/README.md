# Trax Logistics Plugin v2.2.3

Modern WordPress/WooCommerce plugin for Trax Sonic shipment booking with modal-based UI.

## Features

- ✅ Single order booking with preview
- ✅ Bulk order booking
- ✅ Clickable tracking numbers
- ✅ Airway bill download
- ✅ Custom order status "Booked at Trax"
- ✅ HPOS (High-Performance Order Storage) compatible
- ✅ Modern modal-based UI (similar to Leopards Courier)
- ✅ Debug logging
- ✅ No plugin conflicts

## Requirements

- WordPress 5.8+
- WooCommerce 6.0+
- PHP 7.4+
- Valid Trax Sonic API key

## Installation

See [INSTALLATION.md](INSTALLATION.md) for detailed instructions.

Quick steps:
1. Deactivate old Trax plugin (v2.2.1)
2. Upload and activate this plugin (v2.2.3)
3. Configure API key and pickup address in Settings → Trax Logistics
4. Start booking!

## Usage

### Single Order Booking

1. Go to WooCommerce → Orders
2. Open any order
3. Find "Trax Details" meta box in sidebar
4. Click "Create Shipment"
5. Fill/verify booking details in modal
6. Click "Preview" to review
7. Click "Submit" to book

### Bulk Order Booking

1. Go to WooCommerce → Orders
2. Select multiple orders (checkbox)
3. Choose "Book at Trax" from Bulk Actions dropdown
4. Click "Apply"
5. Review orders in modal table
6. Adjust cities/shipping modes if needed
7. Click "Create Bulk Shipment"

### Tracking

- Tracking numbers appear in "Trax Logistics" column on orders list
- Click tracking number to open tracking page
- Click "Download AWB" to get airway bill PDF

## Settings

Go to Settings → Trax Logistics:

- **API Key**: Your Trax Sonic API key
- **Pickup Address**: Select from your registered addresses
- **Default Shipping Mode**: Rush / Saver Plus / Swift
- **Enable Debug Logging**: Turn on for troubleshooting

Debug log location: `wp-content/uploads/trax-debug.log`

## API Endpoints Used

- `GET /api/cities` - Fetch cities list
- `GET /api/pickup_addresses` - Fetch pickup addresses
- `POST /api/shipment/book` - Book shipment
- `POST /api/shipment/air_waybill` - Download airway bill

## Changelog

### v2.2.3 (2026-04-21)
- Complete rewrite with modern UI
- Added modal-based booking (single + bulk)
- Added preview before submission
- Added clickable tracking numbers
- Added airway bill download
- HPOS compatibility
- Fixed plugin conflicts
- Improved error handling
- Better logging

### v2.2.1
- Initial version

## Support

For issues:
1. Enable debug logging in settings
2. Check `wp-content/uploads/trax-debug.log`
3. Contact Trax support with log details

## License

GPLv2 or later

## Author

Trax Logistics - https://trax.pk
