jQuery(document).ready(function($) {
    
    // Cache for API responses
    var traxCache = {
        cities: null,
        orderData: {}
    };
    
    // Single booking modal
    var singleModal = $('#trax-booking-modal');
    var bulkModal = $('#trax-bulk-modal');
    
    // Open single booking modal
    $(document).on('click', '.trax-create-shipment', function(e) {
        e.preventDefault();
        var orderId = $(this).data('order-id');
        openSingleBookingModal(orderId);
    });
    
    // Close modals
    $('.trax-modal-close').on('click', function() {
        $(this).closest('.trax-modal').hide();
    });
    
    // Close modal on outside click
    $(window).on('click', function(e) {
        if ($(e.target).hasClass('trax-modal')) {
            $(e.target).hide();
        }
    });
    
    // Preview button
    $('#trax-preview-btn').on('click', function() {
        showPreview();
    });
    
    // Back button
    $('#trax-back-btn').on('click', function() {
        hidePreview();
    });
    
    // Submit button
    $('#trax-submit-btn').on('click', function() {
        submitBooking();
    });
    
    // Bulk action handler - intercept form submission
    $('body').on('click', '#doaction, #doaction2', function(e) {
        var action = $(this).attr('id') === 'doaction' ? $('#bulk-action-selector-top').val() : $('#bulk-action-selector-bottom').val();
        
        if (action === 'trax_bulk_shipment') {
            e.preventDefault();
            
            var selectedOrders = [];
            $('input[name="post[]"]:checked, input[name="id[]"]:checked').each(function() {
                selectedOrders.push($(this).val());
            });
            
            if (selectedOrders.length > 0) {
                openBulkBookingModal(selectedOrders);
            } else {
                alert('Please select orders first');
            }
            
            return false;
        }
    });
    
    // Bulk submit
    $('#trax-bulk-submit-btn').on('click', function() {
        submitBulkBooking();
    });
    
    // Toggle order details (event delegation for dynamically created rows)
    $(document).on('click', '.trax-toggle-details', function() {
        var orderId = $(this).data('order-id');
        var detailsRow = $('.trax-order-details[data-order-id="' + orderId + '"]');
        
        if (detailsRow.is(':visible')) {
            detailsRow.hide();
            $(this).text('▼');
        } else {
            detailsRow.show();
            $(this).text('▲');
        }
    });
    
    // Remove order from bulk booking
    $(document).on('click', '.trax-remove-order', function() {
        var orderId = $(this).data('order-id');
        var mainRow = $('tr[data-order-id="' + orderId + '"]').not('.trax-order-details');
        var detailsRow = $('.trax-order-details[data-order-id="' + orderId + '"]');
        
        // Fade out and remove both rows
        mainRow.fadeOut(300, function() {
            $(this).remove();
            // Check if any orders remain
            if ($('#trax-bulk-orders-tbody tr').not('.trax-order-details').length === 0) {
                $('#trax-bulk-orders-tbody').html('<tr><td colspan="10" style="text-align:center; padding:20px;">No orders selected</td></tr>');
                $('#trax-bulk-submit-btn').prop('disabled', true);
            }
        });
        detailsRow.fadeOut(300, function() {
            $(this).remove();
        });
    });
    
    // Download airway bill
    $(document).on('click', '.trax-download-airway-bill', function(e) {
        e.preventDefault();
        var trackingNumber = $(this).data('tracking');
        downloadAirwayBill(trackingNumber);
    });
    
    // Cancel shipment
    $(document).on('click', '.trax-cancel-shipment', function(e) {
        e.preventDefault();
        var trackingNumber = $(this).data('tracking');
        var orderId        = $(this).data('order-id');
        var btn            = $(this);
        
        if (!confirm('Are you sure you want to cancel shipment ' + trackingNumber + '? This cannot be undone.')) {
            return;
        }
        
        btn.prop('disabled', true).text('Cancelling...');
        
        $.ajax({
            url: traxVars.ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_cancel_shipment',
                nonce: traxVars.nonce,
                tracking_number: trackingNumber,
                order_id: orderId
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.data.message);
                    location.reload();
                } else {
                    alert('❌ ' + response.data.message);
                    btn.prop('disabled', false).text('✕ Cancel Shipment');
                }
            },
            error: function() {
                alert('❌ Failed to cancel shipment');
                btn.prop('disabled', false).text('✕ Cancel Shipment');
            }
        });
    });
    
    /**
     * Open single booking modal
     */
    function openSingleBookingModal(orderId) {
        // Show modal immediately with form
        singleModal.show();
        
        // Check if we have cached data for this order
        if (traxCache.orderData[orderId] && traxCache.cities) {
            populateSingleBookingForm(traxCache.orderData[orderId], traxCache.cities);
            return;
        }
        
        // Show loading in modal body
        singleModal.find('.trax-modal-body').prepend('<div class="trax-loading-overlay" style="text-align:center; padding:20px;"><p>Loading order data...</p></div>');
        
        $.ajax({
            url: traxVars.ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_get_order_data',
                nonce: traxVars.nonce,
                order_id: orderId
            },
            success: function(response) {
                // Remove loading overlay
                $('.trax-loading-overlay').remove();
                
                if (response.success) {
                    // Cache the data
                    traxCache.orderData[orderId] = response.data.order_data;
                    traxCache.cities = response.data.cities;
                    
                    populateSingleBookingForm(response.data.order_data, response.data.cities);
                } else {
                    alert('Error: ' + response.data.message);
                    singleModal.hide();
                }
            },
            error: function() {
                $('.trax-loading-overlay').remove();
                alert('Failed to load order data');
                singleModal.hide();
            }
        });
    }
    
    /**
     * Populate single booking form
     */
    function populateSingleBookingForm(orderData, cities) {
        // Reset visibility
        $('#trax-preview-section').hide();
        $('#trax-response-message').hide();
        $('#trax-preview-btn').show();
        $('#trax-submit-btn').hide();
        $('#trax-back-btn').hide();
        $('#trax-booking-form').show();
        $('.trax-modal-footer').show();
        
        // Reset form
        var form = document.getElementById('trax-booking-form');
        if (form) form.reset();
        
        // Populate cities dropdown
        var citiesHtml = '<option value="">— Select Destination City —</option>';
        $.each(cities, function(index, city) {
            citiesHtml += '<option value="' + city.id + '">' + city.name + '</option>';
        });
        $('#trax-destination-city').html(citiesHtml);
        initCitySelect2('#trax-destination-city');
        
        // Find matching city - only auto-select if it came from shipping address
        // If city came from billing fallback (no shipping address), leave empty + highlight
        var matchedCityId = null;
        if (orderData.has_shipping_city) {
            matchedCityId = findCityId(orderData.consignee_city, cities);
        }
        
        if (matchedCityId) {
            $('#trax-destination-city').val(matchedCityId).removeClass('trax-invalid');
            $('#trax-destination-city-error').text('');
        } else {
            $('#trax-destination-city').val('').addClass('trax-invalid');
            var cityMsg = orderData.consignee_city
                ? 'City "' + orderData.consignee_city + '" not found — please select manually'
                : 'Please select destination city';
            $('#trax-destination-city-error').text(cityMsg);
        }
        
        // Populate form fields
        $('#trax-order-id').val(orderData.order_id);
        $('#trax-consignee-name').val(orderData.consignee_name);
        $('#trax-consignee-address').val(orderData.consignee_address);
        $('#trax-consignee-email').val(orderData.consignee_email);
        $('#trax-amount').val(orderData.amount);
        $('#trax-parcel-value').val(orderData.parcel_value);
        $('#trax-item-description').val(orderData.item_description);
        $('#trax-item-quantity').val(orderData.item_quantity);
        $('#trax-estimated-weight').val(orderData.estimated_weight);
        $('#trax-special-instructions').val(orderData.special_instructions);
        
        // Phone - validate and highlight
        var phone = orderData.consignee_phone || '';
        $('#trax-consignee-phone').val(phone);
        if (!phone || !isValidPhone(phone)) {
            $('#trax-consignee-phone').addClass('trax-invalid');
            $('#trax-consignee-phone-error').text(!phone ? 'Phone number is required' : 'Invalid format — use 03xxxxxxxxx or +92xxxxxxxxxx');
        } else {
            $('#trax-consignee-phone').removeClass('trax-invalid');
            $('#trax-consignee-phone-error').text('');
        }
        
        // Clear validation on change
        $('#trax-destination-city').off('change.validate').on('change.validate', function() {
            if ($(this).val()) {
                $(this).removeClass('trax-invalid').next('.select2-container').find('.select2-selection').css('border-color', '');
                $('#trax-destination-city-error').text('');
            }
        });
        $('#trax-consignee-phone').off('input.validate').on('input.validate', function() {
            if (isValidPhone($(this).val())) {
                $(this).removeClass('trax-invalid');
                $('#trax-consignee-phone-error').text('');
            }
        });
        
        // Clear validation on input for other required fields
        $('#trax-consignee-name, #trax-consignee-address, #trax-item-description, #trax-item-quantity, #trax-estimated-weight, #trax-amount, #trax-parcel-value')
            .off('input.validate').on('input.validate', function() {
                if ($(this).val() && $(this).val().toString().trim() !== '') {
                    $(this).removeClass('trax-invalid');
                    var errId = '#' + $(this).attr('id') + '-error';
                    $(errId).text('');
                }
            });
    }
    
    /**
     * Validate Pakistani phone number
     */
    function isValidPhone(phone) {
        if (!phone) return false;
        var cleaned = phone.replace(/[\s\-]/g, '');
        return /^03\d{9}$/.test(cleaned) || /^(\+92|0092|92)\d{10}$/.test(cleaned);
    }
    
    /**
     * Initialize Select2 on a city dropdown
     */
    function initCitySelect2(selector) {
        if (typeof $.fn.selectWoo !== 'undefined') {
            $(selector).selectWoo({
                width: '100%',
                placeholder: '— Select City —',
                allowClear: true
            });
        } else if (typeof $.fn.select2 !== 'undefined') {
            $(selector).select2({
                width: '100%',
                placeholder: '— Select City —',
                allowClear: true
            });
        }
    }
    function findCityId(cityName, cities) {
        if (!cityName) return null;
        
        var normalizedName = cityName.toLowerCase().trim();
        
        // Exact match first
        for (var i = 0; i < cities.length; i++) {
            if (cities[i].name.toLowerCase().trim() === normalizedName) {
                return cities[i].id;
            }
        }
        
        // Partial match (starts with)
        for (var i = 0; i < cities.length; i++) {
            if (cities[i].name.toLowerCase().trim().indexOf(normalizedName) === 0) {
                return cities[i].id;
            }
        }
        
        // Contains match
        for (var i = 0; i < cities.length; i++) {
            if (cities[i].name.toLowerCase().trim().indexOf(normalizedName) !== -1) {
                return cities[i].id;
            }
        }
        
        // Remove common suffixes and try again
        var cleanName = normalizedName.replace(/\s+(city|town|district)$/i, '');
        for (var i = 0; i < cities.length; i++) {
            var cleanCityName = cities[i].name.toLowerCase().trim().replace(/\s+(city|town|district)$/i, '');
            if (cleanCityName === cleanName) {
                return cities[i].id;
            }
        }
        
        return null;
    }
    
    /**
     * Show preview
     */
    function showPreview() {
        // Custom validation
        var valid = true;
        
        // Destination city
        if (!$('#trax-destination-city').val()) {
            $('#trax-destination-city').addClass('trax-invalid');
            $('#trax-destination-city-error').text('Please select a destination city');
            valid = false;
        }
        
        // Phone
        var phone = $('#trax-consignee-phone').val();
        if (!phone || !isValidPhone(phone)) {
            $('#trax-consignee-phone').addClass('trax-invalid');
            $('#trax-consignee-phone-error').text(!phone ? 'Phone number is required' : 'Invalid format — use 03xxxxxxxxx or +92xxxxxxxxxx');
            valid = false;
        }
        
        // Required text fields
        var requiredFields = [
            { id: '#trax-consignee-name',    errId: '#trax-consignee-name-error',    label: 'Consignee name' },
            { id: '#trax-consignee-address', errId: '#trax-consignee-address-error', label: 'Consignee address' },
            { id: '#trax-item-description',  errId: '#trax-item-description-error',  label: 'Item description' },
            { id: '#trax-item-quantity',     errId: '#trax-item-quantity-error',     label: 'Item quantity' },
            { id: '#trax-estimated-weight',  errId: '#trax-estimated-weight-error',  label: 'Estimated weight (min 0.1)' },
            { id: '#trax-amount',            errId: '#trax-amount-error',            label: 'COD amount' },
        ];
        
        $.each(requiredFields, function(i, f) {
            var val = $(f.id).val();
            var isEmpty = !val || val.toString().trim() === '';
            var isBelowMin = (f.id === '#trax-estimated-weight' && !isEmpty && parseFloat(val) < 0.1) ||
                             (f.id === '#trax-item-quantity'    && !isEmpty && parseInt(val) < 1);
            if (isEmpty || isBelowMin) {
                $(f.id).addClass('trax-invalid');
                $(f.errId).text(isEmpty ? f.label + ' is required' : f.label + ' is invalid');
                valid = false;
            } else {
                $(f.id).removeClass('trax-invalid');
                $(f.errId).text('');
            }
        });
        
        if (!valid) {
            // Scroll to first error
            var firstInvalid = singleModal.find('.trax-invalid').first();
            if (firstInvalid.length) {
                singleModal.find('.trax-modal-body').animate({ scrollTop: firstInvalid.offset().top - singleModal.find('.trax-modal-body').offset().top - 20 }, 300);
            }
            return;
        }
        
        // Get form data
        var formData = $('#trax-booking-form').serializeArray();
        var previewHtml = '<table><tbody>';
        
        // Add origin city to preview
        previewHtml += '<tr><th>Origin City</th><td>' + ($('#trax-origin-city').val() || '—') + '</td></tr>';
        
        $.each(formData, function(index, field) {
            if (field.name !== 'order_id') {
                var label = $('label[for="trax-' + field.name.replace(/_/g, '-') + '"]').text();
                var value = field.value;
                
                if (field.name === 'consignee_city_id') {
                    value = $('#trax-destination-city option:selected').text();
                }
                if (field.name === 'shipping_mode_id') {
                    value = $('#trax-shipping-mode option:selected').text();
                }
                
                previewHtml += '<tr><th>' + label + '</th><td>' + value + '</td></tr>';
            }
        });
        
        previewHtml += '</tbody></table>';
        
        $('#trax-preview-content').html(previewHtml);
        $('#trax-preview-section').show();
        $('#trax-preview-btn').hide();
        $('#trax-submit-btn').show();
        $('#trax-back-btn').show();
    }
    
    /**
     * Hide preview
     */
    function hidePreview() {
        $('#trax-preview-section').hide();
        $('#trax-preview-btn').show();
        $('#trax-submit-btn').hide();
        $('#trax-back-btn').hide();
    }
    
    /**
     * Submit booking
     */
    function submitBooking() {
        $('#trax-submit-btn').prop('disabled', true).text('Booking...');
        
        // Explicitly collect all field values (don't rely on serializeArray for numbers)
        var orderId = $('#trax-order-id').val();
        var formData = {
            order_id:             orderId,
            consignee_city_id:    $('#trax-destination-city').val(),
            shipping_mode_id:     $('#trax-shipping-mode').val(),
            consignee_name:       $('#trax-consignee-name').val(),
            consignee_address:    $('#trax-consignee-address').val(),
            consignee_phone:      $('#trax-consignee-phone').val(),
            consignee_email:      $('#trax-consignee-email').val(),
            amount:               $('#trax-amount').val(),
            parcel_value:         $('#trax-parcel-value').val(),
            item_description:     $('#trax-item-description').val(),
            item_quantity:        $('#trax-item-quantity').val(),
            estimated_weight:     $('#trax-estimated-weight').val(),
            special_instructions: $('#trax-special-instructions').val()
        };
        
        $.ajax({
            url: traxVars.ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_book_shipment',
                nonce: traxVars.nonce,
                order_id: orderId,
                booking_data: formData
            },
            success: function(response) {
                if (response.success) {
                    var hasWarnings = response.data.non_service_area || response.data.blacklisted_consignee || response.data.bdmk_message || response.data.video;
                    
                    var message = '<strong>✅ Success!</strong> ' + response.data.message + '<br>Tracking Number: <strong>' + response.data.tracking_number + '</strong>';
                    
                    if (response.data.non_service_area) {
                        message += '<div style="background:#fff3cd;padding:10px;border-left:4px solid #ffc107;margin-top:10px;">⚠️ <strong>Non-Service Area:</strong><br>' + response.data.non_service_area + '</div>';
                    }
                    if (response.data.blacklisted_consignee) {
                        message += '<div style="background:#f8d7da;padding:10px;border-left:4px solid #dc3545;margin-top:10px;">🚫 <strong>Blacklisted Consignee:</strong><br>' + response.data.blacklisted_consignee + '</div>';
                    }
                    if (response.data.bdmk_message) {
                        message += '<div style="background:#fff3cd;padding:10px;border-left:4px solid #ffc107;margin-top:10px;">⚠️ ' + response.data.bdmk_message + '</div>';
                    }
                    if (response.data.video && Array.isArray(response.data.video) && response.data.video.length >= 2) {
                        message += '<div style="background:#d1ecf1;padding:10px;border-left:4px solid #17a2b8;margin-top:10px;">📹 <strong>Important Video:</strong><br><a href="' + response.data.video[0] + '" target="_blank">' + response.data.video[0] + '</a><br><small>' + response.data.video[1] + '</small></div>';
                    }
                    
                    if (hasWarnings) {
                        message += '<div style="margin-top:12px;"><button type="button" class="button button-primary" id="trax-close-reload">OK, Close & Refresh</button></div>';
                    }
                    
                    $('#trax-response-message')
                        .removeClass('error').addClass('success')
                        .html(message).show();
                    
                    $('#trax-booking-form').hide();
                    $('#trax-preview-section').hide();
                    $('.trax-modal-footer').hide();
                    
                    if (!hasWarnings) {
                        // No warnings — reload after 3 seconds
                        setTimeout(function() { location.reload(); }, 3000);
                    }
                    // If warnings — user must click the button to reload
                    $(document).off('click', '#trax-close-reload').on('click', '#trax-close-reload', function() {
                        location.reload();
                    });
                } else {
                    $('#trax-response-message')
                        .removeClass('success')
                        .addClass('error')
                        .html('<strong>Error!</strong> ' + response.data.message)
                        .show();
                    
                    $('#trax-submit-btn').prop('disabled', false).text('Submit');
                }
            },
            error: function() {
                $('#trax-response-message')
                    .removeClass('success')
                    .addClass('error')
                    .html('<strong>Error!</strong> Failed to book shipment')
                    .show();
                
                $('#trax-submit-btn').prop('disabled', false).text('Submit');
            }
        });
    }
    
    /**
     * Open bulk booking modal
     */
    function openBulkBookingModal(orderIds) {
        bulkModal.find('#trax-bulk-orders-tbody').html('<tr><td colspan="8">Loading orders...</td></tr>');
        bulkModal.show();
        
        // Check if we have cached cities
        if (traxCache.cities) {
            // Use cached cities, only fetch order data
            fetchBulkOrders(orderIds, traxCache.cities);
        } else {
            // Fetch everything
            $.ajax({
                url: traxVars.ajaxurl,
                type: 'POST',
                data: {
                    action: 'trax_bulk_check_orders',
                    nonce: traxVars.nonce,
                    order_ids: orderIds
                },
                success: function(response) {
                    if (response.success) {
                        // Cache cities
                        traxCache.cities = response.data.cities;
                        
                        populateBulkBookingTable(response.data.orders, response.data.cities);
                    } else {
                        alert('Error: ' + response.data.message);
                        bulkModal.hide();
                    }
                },
                error: function() {
                    alert('Failed to load orders');
                    bulkModal.hide();
                }
            });
        }
    }
    
    /**
     * Fetch bulk orders with cached cities
     */
    function fetchBulkOrders(orderIds, cities) {
        $.ajax({
            url: traxVars.ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_bulk_check_orders',
                nonce: traxVars.nonce,
                order_ids: orderIds
            },
            success: function(response) {
                if (response.success) {
                    populateBulkBookingTable(response.data.orders, cities);
                } else {
                    alert('Error: ' + response.data.message);
                    bulkModal.hide();
                }
            },
            error: function() {
                alert('Failed to load orders');
                bulkModal.hide();
            }
        });
    }
    
    /**
     * Populate bulk booking table
     */
    function populateBulkBookingTable(orders, cities) {
        var tbody = $('#trax-bulk-orders-tbody');
        tbody.empty();
        
        // Build cities dropdown HTML
        var citiesHtml = '<option value="">— Select City —</option>';
        $.each(cities, function(index, city) {
            citiesHtml += '<option value="' + city.id + '">' + city.name + '</option>';
        });
        
        // Origin city from settings (read-only display)
        var originCityName = traxVars.pickupCityName || '⚠️ Not set';
        
        $.each(orders, function(index, order) {
            var rowClass = '';
            var statusText = '';
            var matchedCityId = null;
            
            if (order.is_booked) {
                rowClass = 'order-booked';
                statusText = 'Already Booked: ' + order.tracking_number;
            } else {
                // Only auto-match if city came from shipping address, not billing fallback
                if (order.has_shipping_city) {
                    matchedCityId = findCityId(order.consignee_city, cities);
                }
                if (matchedCityId) {
                    rowClass = 'order-matched';
                    statusText = 'Ready';
                } else {
                    rowClass = 'order-not-matched';
                    statusText = 'City Not Found';
                }
            }
            
            // Destination City dropdown - empty + highlighted if not matched
            var destCitySelect = '<select class="trax-bulk-city' + (!matchedCityId ? ' trax-invalid' : '') + '" data-order-id="' + order.order_id + '">' + citiesHtml + '</select>';
            if (matchedCityId) {
                destCitySelect = destCitySelect.replace('value="' + matchedCityId + '"', 'value="' + matchedCityId + '" selected');
            }
            
            // Phone validation
            var phone = order.consignee_phone || '';
            var phoneValid = isValidPhone(phone);
            var phoneClass = (!phone || !phoneValid) ? ' trax-invalid' : '';
            
            var row = '<tr class="' + rowClass + '" data-order-id="' + order.order_id + '">' +
                '<td><a href="post.php?post=' + order.order_id + '&action=edit" target="_blank">#' + order.order_number + '</a></td>' +
                '<td>' + destCitySelect + '</td>' +
                '<td><input type="text" class="trax-bulk-name" value="' + escHtml(order.consignee_name) + '"></td>' +
                '<td><input type="text" class="trax-bulk-phone' + phoneClass + '" value="' + escHtml(phone) + '" placeholder="03xxxxxxxxx"></td>' +
                '<td><select class="trax-bulk-shipping-mode"><option value="1">Rush</option><option value="2">Saver Plus</option><option value="3">Swift</option></select></td>' +
                '<td><input type="number" class="trax-bulk-price" value="' + order.amount + '" step="0.01"></td>' +
                '<td><input type="number" class="trax-bulk-weight" value="' + order.estimated_weight + '" step="0.01"></td>' +
                '<td class="trax-bulk-status">' + statusText + '</td>' +
                '<td style="text-align:center;"><button type="button" class="button button-small trax-toggle-details" data-order-id="' + order.order_id + '">▼</button></td>' +
                '<td style="text-align:center;"><button type="button" class="button button-small trax-remove-order" data-order-id="' + order.order_id + '" style="color:#a00;">✕</button></td>' +
                '</tr>';
            
            // Fully editable details row - values posted on booking
            var detailsRow = '<tr class="trax-order-details" data-order-id="' + order.order_id + '" style="display:none;">' +
                '<td colspan="10" style="background:#f9f9f9; padding:15px;">' +
                '<div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Address</label>' +
                '<textarea class="trax-bulk-address" rows="2" style="width:100%;font-size:12px;">' + escHtml(order.consignee_address) + '</textarea></div>' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Email</label>' +
                '<input type="text" class="trax-bulk-email" value="' + escHtml(order.consignee_email || '') + '" style="width:100%;font-size:12px;"></div>' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Payment Method</label>' +
                '<span style="font-size:12px;">' + escHtml(order.payment_method) + '</span></div>' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Special Instructions</label>' +
                '<input type="text" class="trax-bulk-instructions" value="' + escHtml(order.special_instructions || '') + '" style="width:100%;font-size:12px;"></div>' +
                '<div style="grid-column:1/-1;"><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Item Description</label>' +
                '<textarea class="trax-bulk-item-desc" rows="2" style="width:100%;font-size:12px;">' + escHtml(order.item_description) + '</textarea></div>' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Item Quantity</label>' +
                '<input type="number" class="trax-bulk-item-qty" value="' + order.item_quantity + '" min="1" style="width:100%;font-size:12px;"></div>' +
                '<div><label style="font-weight:600;font-size:12px;display:block;margin-bottom:3px;">Parcel Value</label>' +
                '<input type="number" class="trax-bulk-parcel-value" value="' + order.parcel_value + '" step="0.01" style="width:100%;font-size:12px;"></div>' +
                '</div>' +
                '</td>' +
                '</tr>';
            
            tbody.append(row);
            tbody.append(detailsRow);
        });
        
        // Init Select2 on all bulk city dropdowns
        setTimeout(function() {
            $('.trax-bulk-city').each(function() {
                initCitySelect2(this);
            });
        }, 50);
        
        // Live phone validation in bulk table
        $(document).off('input.bulkphone', '.trax-bulk-phone').on('input.bulkphone', '.trax-bulk-phone', function() {
            if (isValidPhone($(this).val())) {
                $(this).removeClass('trax-invalid');
            } else {
                $(this).addClass('trax-invalid');
            }
        });
        
        // Clear city error on selection
        $(document).off('change.bulkcity', '.trax-bulk-city').on('change.bulkcity', '.trax-bulk-city', function() {
            if ($(this).val()) {
                $(this).removeClass('trax-invalid');
                $(this).closest('tr').find('.trax-bulk-status').text('Ready').css('color', '');
            }
        });
        
        // Clear validation on input for bulk fields
        $(document).off('input.bulkvalidate', '.trax-bulk-name, .trax-bulk-price, .trax-bulk-weight, .trax-bulk-address, .trax-bulk-item-desc, .trax-bulk-item-qty')
            .on('input.bulkvalidate', '.trax-bulk-name, .trax-bulk-price, .trax-bulk-weight, .trax-bulk-address, .trax-bulk-item-desc, .trax-bulk-item-qty', function() {
                if ($(this).val() && $(this).val().toString().trim() !== '') {
                    $(this).removeClass('trax-invalid');
                }
            });
        
        // Sync customer city with Trax city when changed
        $(document).off('change', '.trax-bulk-customer-city').on('change', '.trax-bulk-customer-city', function() {
            var selectedCity = $(this).val();
            $(this).closest('tr').find('.trax-bulk-city').val(selectedCity);
        });
    }
    
    /**
     * Escape HTML helper
     */
    function escHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    
    /**
     * Submit bulk booking
     */
    function submitBulkBooking() {
        var orders = [];
        var hasErrors = false;
        
        $('#trax-bulk-orders-tbody tr').not('.trax-order-details').each(function() {
            var row = $(this);
            var orderId = row.data('order-id');
            
            if (!orderId) return;
            if (row.hasClass('order-booked')) return;
            
            var cityId       = row.find('.trax-bulk-city').val();
            var phone        = row.find('.trax-bulk-phone').val();
            var shippingMode = row.find('.trax-bulk-shipping-mode').val();
            var price        = row.find('.trax-bulk-price').val();
            var weight       = row.find('.trax-bulk-weight').val();
            var customerName = row.find('.trax-bulk-name').val();
            
            // Read editable details from the details row
            var detailsRow   = $('.trax-order-details[data-order-id="' + orderId + '"]');
            var address      = detailsRow.find('.trax-bulk-address').val() || '';
            var email        = detailsRow.find('.trax-bulk-email').val() || '';
            var itemDesc     = detailsRow.find('.trax-bulk-item-desc').val() || '';
            var itemQty      = detailsRow.find('.trax-bulk-item-qty').val() || '';
            var parcelValue  = detailsRow.find('.trax-bulk-parcel-value').val() || '';
            var instructions = detailsRow.find('.trax-bulk-instructions').val() || '';
            
            var rowErrors = [];
            var needsExpand = false;
            
            // City
            if (!cityId) {
                row.find('.trax-bulk-city').addClass('trax-invalid');
                rowErrors.push('City'); hasErrors = true;
            }
            // Phone
            if (!phone || !isValidPhone(phone)) {
                row.find('.trax-bulk-phone').addClass('trax-invalid');
                rowErrors.push('Phone'); hasErrors = true;
            }
            // Name
            if (!customerName || !customerName.trim()) {
                row.find('.trax-bulk-name').addClass('trax-invalid');
                rowErrors.push('Name'); hasErrors = true;
            }
            // Weight
            if (!weight || parseFloat(weight) < 0.1) {
                row.find('.trax-bulk-weight').addClass('trax-invalid');
                rowErrors.push('Weight'); hasErrors = true;
            }
            // Price
            if (price === '' || isNaN(parseFloat(price))) {
                row.find('.trax-bulk-price').addClass('trax-invalid');
                rowErrors.push('Price'); hasErrors = true;
            }
            // Address (in details row)
            if (!address || !address.trim()) {
                detailsRow.find('.trax-bulk-address').addClass('trax-invalid');
                rowErrors.push('Address'); hasErrors = true; needsExpand = true;
            }
            // Item description
            if (!itemDesc || !itemDesc.trim()) {
                detailsRow.find('.trax-bulk-item-desc').addClass('trax-invalid');
                rowErrors.push('Item Desc'); hasErrors = true; needsExpand = true;
            }
            // Item quantity
            if (!itemQty || parseInt(itemQty) < 1) {
                detailsRow.find('.trax-bulk-item-qty').addClass('trax-invalid');
                rowErrors.push('Qty'); hasErrors = true; needsExpand = true;
            }
            
            if (needsExpand) {
                detailsRow.show();
                row.find('.trax-toggle-details').text('▲');
            }
            
            if (rowErrors.length > 0) {
                row.find('.trax-bulk-status').html('<span style="color:red;font-size:11px;">⚠️ ' + rowErrors.join(', ') + '</span>');
                return;
            }
            
            orders.push({
                order_id:      orderId,
                city_id:       cityId,
                shipping_mode: shippingMode,
                price:         price,
                weight:        weight,
                customer_name: customerName,
                phone:         phone,
                address:       address,
                email:         email,
                item_description: itemDesc,
                item_quantity:    itemQty,
                parcel_value:     parcelValue,
                instructions:     instructions
            });
        });
        
        if (hasErrors) {
            alert('Please fix highlighted errors before submitting');
            return;
        }
        
        if (orders.length === 0) {
            alert('No orders to book');
            return;
        }
        
        $('#trax-bulk-submit-btn').prop('disabled', true).text('Booking ' + orders.length + ' orders...');
        
        var successCount = 0;
        var failCount = 0;
        var hasAnyWarning = false;
        
        function bookNextOrder(index) {
            if (index >= orders.length) {
                var summary = '<strong>Booking Complete!</strong> Success: ' + successCount + ' | Failed: ' + failCount;
                if (hasAnyWarning) {
                    summary += '<br><small style="color:#856404;">⚠️ Some orders have warnings — review status column above</small>';
                }
                summary += '<br><button type="button" class="button button-primary" style="margin-top:8px;" id="trax-bulk-done-btn">Close & Refresh</button>';
                
                $('#trax-bulk-response').html('<p>' + summary + '</p>').show();
                $('#trax-bulk-submit-btn').prop('disabled', true).text('Booking Done');
                
                if (!hasAnyWarning) {
                    setTimeout(function() { location.reload(); }, 3000);
                }
                
                // Close & Refresh button
                $(document).off('click', '#trax-bulk-done-btn').on('click', '#trax-bulk-done-btn', function() {
                    location.reload();
                });
                
                // If user closes modal without clicking the button, force reload
                $('.trax-modal-close, #trax-bulk-modal').off('click.donereload').on('click.donereload', function() {
                    location.reload();
                });
                return;
            }
            
            var order = orders[index];
            var row = $('#trax-bulk-orders-tbody tr[data-order-id="' + order.order_id + '"]').not('.trax-order-details');
            row.find('.trax-bulk-status').text('Booking...').css('color', 'blue');
            
            var bookingData = {
                consignee_city_id:    order.city_id,
                shipping_mode_id:     order.shipping_mode,
                consignee_name:       order.customer_name,
                consignee_address:    order.address,
                consignee_phone:      order.phone,
                consignee_email:      order.email,
                amount:               order.price,
                parcel_value:         order.parcel_value,
                item_description:     order.item_description,
                item_quantity:        order.item_quantity,
                estimated_weight:     order.weight,
                special_instructions: order.instructions
            };
            
            $.ajax({
                url: traxVars.ajaxurl,
                type: 'POST',
                data: {
                    action: 'trax_book_shipment',
                    nonce: traxVars.nonce,
                    order_id: order.order_id,
                    booking_data: bookingData
                },
                success: function(bookResponse) {
                    if (bookResponse.success) {
                        var statusHtml = '<span style="color:green;font-weight:600;">✅ ' + bookResponse.data.tracking_number + '</span>';
                        
                        // Show warnings inline below status
                        var warnings = '';
                        if (bookResponse.data.non_service_area) {
                            warnings += '<div style="background:#fff3cd;border-left:3px solid #ffc107;padding:4px 6px;margin-top:4px;font-size:11px;">⚠️ ' + bookResponse.data.non_service_area + '</div>';
                        }
                        if (bookResponse.data.blacklisted_consignee) {
                            warnings += '<div style="background:#f8d7da;border-left:3px solid #dc3545;padding:4px 6px;margin-top:4px;font-size:11px;">🚫 ' + bookResponse.data.blacklisted_consignee + '</div>';
                        }
                        if (bookResponse.data.bdmk_message) {
                            warnings += '<div style="background:#fff3cd;border-left:3px solid #ffc107;padding:4px 6px;margin-top:4px;font-size:11px;">⚠️ ' + bookResponse.data.bdmk_message + '</div>';
                        }
                        if (bookResponse.data.video && Array.isArray(bookResponse.data.video)) {
                            warnings += '<div style="background:#d1ecf1;border-left:3px solid #17a2b8;padding:4px 6px;margin-top:4px;font-size:11px;">📹 <a href="' + bookResponse.data.video[0] + '" target="_blank">Watch Video</a></div>';
                        }
                        if (warnings) hasAnyWarning = true;
                        
                        row.find('.trax-bulk-status').html(statusHtml + warnings);
                        successCount++;
                    } else {
                        row.find('.trax-bulk-status').html('<span style="color:red;">❌ ' + bookResponse.data.message + '</span>');
                        failCount++;
                    }
                    bookNextOrder(index + 1);
                },
                error: function() {
                    row.find('.trax-bulk-status').html('<span style="color:red;">❌ Network error</span>');
                    failCount++;
                    bookNextOrder(index + 1);
                }
            });
        }
        
        bookNextOrder(0);
    }
    
    /**
     * Download airway bill
     */
    function downloadAirwayBill(trackingNumber) {
        var btn = $('.trax-download-airway-bill[data-tracking="' + trackingNumber + '"]');
        btn.text('⏳ Loading...').css('pointer-events', 'none');
        
        $.ajax({
            url: traxVars.ajaxurl,
            type: 'POST',
            data: {
                action: 'trax_download_airway_bill',
                nonce: traxVars.nonce,
                tracking_number: trackingNumber
            },
            success: function(response) {
                btn.text('📄 Print AWB').css('pointer-events', 'auto');
                if (response.success && response.data.base64) {
                    // Convert base64 to blob and open in new tab for printing
                    var byteChars = atob(response.data.base64);
                    var byteNums = new Array(byteChars.length);
                    for (var i = 0; i < byteChars.length; i++) {
                        byteNums[i] = byteChars.charCodeAt(i);
                    }
                    var byteArray = new Uint8Array(byteNums);
                    var blob = new Blob([byteArray], { type: response.data.mime });
                    var url = URL.createObjectURL(blob);
                    window.open(url, '_blank');
                } else {
                    alert('Failed to get AWB: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function() {
                btn.text('📄 Print AWB').css('pointer-events', 'auto');
                alert('Failed to download AWB');
            }
        });
    }
});
