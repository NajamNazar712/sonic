<?php
if($_POST)
{
    if(isset($_POST['order']))
    {
        require_once(ABSPATH . 'wp-config.php');

        $baseUrl = "https://sonic.pk/";

        $orders = $_POST['order'];
        

        $headers = ['Authorization:' . $apiKey, 'Accepts:' . 'application/json'];
        $pickup_address_id  = get_option('trax_sonic_pickup_address_id');
        $shipping_mode_id  = 1;
        

        $ch = curl_init();

        $apiUrl = $baseUrl."api/shipment/book";
        $msgs = '';

        $date = new DateTime("now", new DateTimeZone('Asia/Karachi'));
        $date = $date->format('Y-m-d');

        $bulk_shipping_mode = $_POST['bulk_shipping_mode'];

        foreach($orders as $order)
        {
            

            $data = [];
            $data['order_id'] = $order['order_id'];
            $data['service_type_id'] = 1;

            if($order['shipping_mode_id'] == ''){
                $shipping_mode_id = $bulk_shipping_mode;
            }
            else{
                $shipping_mode_id = $order['shipping_mode_id'];
            }
            $data['shipping_mode_id'] = (int)$shipping_mode_id;


            $data['pickup_address_id'] = $pickup_address_id;
            $data['information_display'] = 1;
            $data['consignee_city_id'] = $order['consignee_city'];
            $data['consignee_name'] = trim($order['consignee_name']);
            $data['consignee_address'] = trim($order['consignee_address']);
            $data['consignee_phone_number_1'] = trim($order['consignee_phone']);

            if (!empty(trim($order['consignee_email']))) {
                $data['consignee_email_address'] = trim($order['consignee_email']);
            }

            $data['item_product_type_id'] = 24;
            $data['item_description'] = trim($order['item_description']);
            $data['item_quantity'] = (int)$order['item_quantity'];
            $data['item_insurance'] = 0;
            $data['item_price'] = '';
            $data['pickup_date'] = $date;

            if(trim($order['spec_instructions']))
            {
                $data['special_instructions'] = trim($order['spec_instructions']);
            }

            $data['estimated_weight'] = 1;
            
            $order_details = wc_get_order( $order['order_id'] );
            $payment_method = $order_details->get_payment_method();
            $amount = 0;
            if($payment_method == 'cod' || $payment_method == 'cheque ' || $payment_method == 'bacs')
            {
                $amount = (double)$order['amount'];
            }
            $data['amount'] = $amount;
            if($amount == 0){
                $data['parcel_value'] = (int)$order['parcel_value'];
            }
            $data['payment_mode_id'] = 1;
            
            curl_setopt($ch,CURLOPT_URL, $apiUrl);
            curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch,CURLOPT_POST, true);
            curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            try
            {
                //execute post
                $result = curl_exec($ch);
            }
            catch(Exception $e)
            {
                die($e->getMessage());
            }

            $response = json_decode($result,true);

            $msgs .= "\r\n\r\n<h3><u>Order#".$order['order_id'].'</u></h3>';

            if($response['status'] != 0)
            {
                if (isset($response['errors'])) {
                    foreach($response['errors'] as $field => $err)
                    {
                        $msgs .= "\r\n".$err[0];
                    }
                }
                else {
                    $msgs .= "\r\n".$response['message'];
                }
            }
            else
            {
                $note = "Shipment has been booked. CN # {$response['tracking_number']}.\r\n<a target='_blank' href={$baseUrl}\"tracking?tracking_number={$response['tracking_number']}\">Click to Track order</a>";

                $order_id = $order['order_id'];

                $order = new WC_Order($order['order_id']);

                //Add Order comment
                $order->add_order_note("Order Status updated to Booked at Trax");
                $order->add_order_note($note);

                //Update status
                 $order->update_status('trax-booked');

                global $wpdb;
                $wpdb->insert($wpdb->prefix."postmeta", array('post_id' => $order_id, 'meta_key' => 'booked_by', 'meta_value' => 'Trax'));
                $wpdb->insert($wpdb->prefix."postmeta", array('post_id' => $order_id, 'meta_key' => 'tracking_number', 'meta_value' => $response['tracking_number']));

                $msgs .= "\r\n".$response['message'].' Tracking # '.$response['tracking_number'];
            }
        }

        //close connection
        curl_close($ch);

        if($msgs!=''){

            // wp_head();
            echo '<pre style="text-align:center;">';
            echo $msgs;
            echo "\n\n";
            

            ?><input type='button' id= 'go-back-btn' value='Go Back' class="go-back-trax"/>
            <?php
            // wp_footer();
            ?>
            <style type="text/css">
                .go-back-trax{
                    padding: 10px;font-weight: bold;border: 1px solid #000;border-radius: 25px;cursor: pointer;"
                }
                .go-back-trax:hover{
                    background-color: #ccc;
                    border:white;
                }
            </style>
            <script>
                document.getElementById("go-back-btn").onclick = function ()
                {
                    location.href = "<?= get_admin_url(null, 'edit.php?post_type=shop_order') ?>";
                };
            </script>
            <?php
        }
    }
}
