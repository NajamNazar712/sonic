<?php
/**
* Plugin Name: Trax Logistics
* Description: Trax Sonic Shipment Booking Plugin
* Version: 1.0
* Author: Trax Logistics
* Author URI: https://trax.pk
**/
require_once(ABSPATH . 'wp-config.php');

function register_shipment_arrival_order_status() {
    register_post_status( 'wc-trax-booked', array(
        'label'                     => 'Booked at Trax',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Booked at Trax <span class="count">(%s)</span>', 'Booked at Trax <span class="count">(%s)</span>' )
    ) );
}
add_action( 'init', 'register_shipment_arrival_order_status' );

function add_awaiting_shipment_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-processing' === $key ) {
            $new_order_statuses['wc-trax-booked'] = 'Booked at Trax';
        }
    }
    return $new_order_statuses;
}

add_filter( 'wc_order_statuses', 'add_awaiting_shipment_to_order_statuses' );

 add_filter( 'manage_edit-shop_order_columns', 'trax_function' );

 function trax_function($columns){
          $new_columns = (is_array($columns)) ? $columns : array();
          unset( $new_columns['order_actions'] );

          //all of your columns will be added before the actions column
          $new_columns['trax'] = 'Trax Logistics';
          //stop editing

          $new_columns['order_actions'] = $columns['order_actions'];
          return $new_columns;
  }

  add_action( 'manage_shop_order_posts_custom_column', 'trax_value_function', 2 );
	function trax_value_function($column){
		global $post;
		$data = get_post_meta($post->ID);

      	if ($column == 'trax') {
			global $wpdb;

			$result = $wpdb->get_results("SELECT *  FROM ".$wpdb->prefix."postmeta where  post_id =".$post->ID);

			$tracking_link = '';

			foreach($result as $row) {
				if($row->meta_key == 'tracking_number') {
				  $tracking_link = '<a target="_blank" href="https://sonic.pk/tracking?tracking_number=' . $row->meta_value . '">Track Shipment: ' . $row->meta_value . '</a>';
				}
			}

			if (!empty($tracking_link)) {
				echo $tracking_link;
			}
		}
	}



function submit_form()
{
	if (!empty($_POST['form_submitted']))
	{
		$apiKey  = get_option('trax_sonic_api');

		if($apiKey == '') { die('Please specify valid Sonic API Key'); }

		ob_start();
		include('submit_booking.php');
		echo ob_get_clean();
		die;
	}
}

add_action( 'init', 'submit_form' );

//Trax plugin -- START

add_filter( 'bulk_actions-edit-shop_order', 'trax_my_bulk_actions' );

function trax_my_bulk_actions( $bulk_array ) {

	$bulk_array['trax_orders'] = 'Book at Trax';
	return $bulk_array;

}

add_filter( 'handle_bulk_actions-edit-shop_order', 'trax_bulk_action_handler', 10, 3 );

function trax_bulk_action_handler( $redirect, $doaction, $object_ids )
{
	$apiKey  = get_option('trax_sonic_api');

	if($apiKey == '') { die('Please specify valid Sonic API Key'); }

	$addrList = [];
	$baseUrl = "https://sonic.pk/";
	$apiKey = get_option('trax_sonic_api');
	$apiUrl = $baseUrl . "api/pickup_addresses";
    $headers = ['Authorization:' . $apiKey, 'Accepts:' . 'application/json'];

	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL, $apiUrl);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	try
	{
		$result = curl_exec($ch);
	}
	catch(Exception $e)
	{
		die($e->getMessage());
	}

	$result = json_decode($result,true);

	if($result['status'] == 0)
	{
		$addresses = $result['pickup_addresses'];

		foreach($addresses as $address)
		{
			if ($address['status']) {
				$addrList[$address['id']] = $address['address']. ', '. $address['city']['name'];
			}
		}
	}

	wp_head();
	require_once( ABSPATH . 'wp-admin/admin-header.php' );
?>
	<style>
@import url('https://fonts.googleapis.com/css?family=Roboto&display=swap');

*
	{
	font-family: 'Roboto', sans-serif;
	}

.form-box
	{
	padding: 21px 29px;
	width: 50%;
	}

	.form-box h3
		{
		color: #736969;
		}

		.form-box h1,h2
			{
			text-transform: uppercase;
			border-bottom: 1px solid #dedede;
			padding-bottom: 15px;
			color: #736969;
			}

	.form-box .order-label
		{
		background: #23282d;
		}

		.form-box .order-label h2
			{
			border: 0;
			margin-bottom: 0;
			color: #ffffff;
			font-size: 20px;
			padding: 10px 15px;
			}

	.form-box table
		{
		text-align: left;
		width: 100%;
		background: #f7f7f7;
		padding: 27px 30px;
		margin-bottom: 35px;
		}

		.form-box table tr
			{
			margin-bottom: 13px;
			display: block;
			}

		.form-box table td

			{
			padding: 5px 3px;
			display: block;
			}

	.form-box table th
		{
		width: 100%;
		display: block;
		}

		.form-box input
			{
			width: 100%;
			padding: 12px 10px;
			border: 1px solid #e6e4e4;
			margin-top: 4px;
			border-radius: 5px;
			}

			.form-box select
				{
				width: 100%;
				width: 100%;
				padding: 12px 10px;
				border: 1px solid #e6e4e4;
				margin-top: 4px;
				border-radius: 5px;
				}

				.form-box textarea
					{
					width: 100%;
					padding: 12px 10px;
					border: 1px solid #e6e4e4;
					margin-top: 4px;
					border-radius: 5px;
					min-height: 130px;
					resize: none;
					outline: none;
					}

					.form-box input[type=submit]
						{
						width: 159px;
						text-transform: uppercase;
						background: #0673aa;
						color: #fff;
						font-weight: bold;
						}

						.form-box label
							{
							color: #524b4b;
							font-weight: 300;
							}



	</style>
	<div class="form-box">
	  <?php //screen_icon(); ?>
	  <h1>Order Shipment Booking with Trax</h1>
	  <form method="post">
	  	<input type="hidden" name="form_submitted" value="true" />
		  <?php  submit_button(); ?>
<?php
		$count = 0;
		$skip = 0;

		foreach($object_ids as $orderId)
		{
			$getOrder = new WC_Order($orderId);
	    	$getOrder = $getOrder->get_data();

	    	if($getOrder['status'] == 'trax-booked')
	    	{
	    		$skip++;

	    		if(count($object_ids) == $skip)
	    		{
	    			wp_redirect(wp_get_referer());
	    			die;
	    		}


	    		continue;
	    	}

			$count++;
			$itemDesc = '';
			$itemQty = 0;

			//Get Order Info
			$order = new WC_Order($orderId);
			$orderData = $order->get_data();

			foreach($orderData['line_items'] as $item)
			{
				$item_data = $item->get_data();

				$itemQty += $item_data['quantity'];
				$itemDesc .= $item_data['name'] . "\r\n";
			}

			if (trim($orderData['shipping']['first_name']) != '') {
				$first_name = $orderData['shipping']['first_name'];
			}
			else {
				$first_name = $orderData['billing']['first_name'];
			}

			if (trim($orderData['shipping']['last_name']) != '') {
				$last_name = $orderData['shipping']['last_name'];
			}
			else {
				$last_name = $orderData['billing']['last_name'];
			}

			if (trim($orderData['shipping']['address_1']) != '') {
				$address_1 = $orderData['shipping']['address_1'];
			}
			else {
				$address_1 = $orderData['billing']['address_1'];
			}

			if (trim($orderData['shipping']['address_2']) != '') {
				$address_2 = $orderData['shipping']['address_2'];
			}
			else {
				$address_2 = $orderData['billing']['address_2'];
			}

			if (trim($orderData['shipping']['phone']) != '') {
				$phone = $orderData['shipping']['phone'];
			}
			else {
				$phone = $orderData['billing']['phone'];
			}

			if (trim($orderData['shipping']['email']) != '') {
				$email = $orderData['shipping']['email'];
			}
			else {
				$email = $orderData['billing']['email'];
			}

			if (trim($orderData['shipping']['city']) != '') {
				$city = $orderData['shipping']['city'];
			}
			else {
				$city = $orderData['billing']['city'];
			}
?>
		<div class='order-label'><h2><?= $count ?>. Order # <?= $orderId?></h2></div>
		<table>
			<input type="hidden" id="order_id_<?= $count ?>" name="order[<?= $count ?>][order_id]" value="<?= $orderId ?>" required/>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="consignee_name_<?= $count ?>">Consignee Name</label>
			  </th>
			  <td>
			  	<input type="text" id="consignee_name_<?= $count ?>" name="order[<?= $count ?>][consignee_name]" value="<?= $first_name.' '.$last_name?>" required/>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="consignee_address_<?= $count ?>">Consignee Address</label>
			  </th>
			  <td>
			  	<textarea required id="consignee_address_<?= $count ?>" name="order[<?= $count ?>][consignee_address]"><?= $address_1."\r\n".$address_2?></textarea>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="consignee_phone_<?= $count ?>">Consignee Phone#</label>
			  </th>
			  <td>
			  	<input type="text" id="consignee_phone_<?= $count ?>" name="order[<?= $count ?>][consignee_phone]" value="<?= $phone?>" pattern="[0-9]{3,11}" placeholder='03xxxxxxxxx' required/>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="consignee_email_<?= $count ?>">Consignee Email</label>
			  </th>
			  <td>
			  	<input type="email" id="consignee_email_<?= $count ?>" name="order[<?= $count ?>][consignee_email]" value="<?= $email?>" />
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="consignee_city_<?= $count ?>">Consignee City</label>
			  </th>
			  <td>
			  	<input type="text" id="consignee_city_<?= $count ?>" name="order[<?= $count ?>][consignee_city]" value="<?= $city?>" required/>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="pickup_address_<?= $count ?>">Pickup Address</label>
			  </th>
			  <td>
			  	<select id="pickup_address_<?= $count ?>" name="order[<?= $count ?>][pickup_address]">
			  	<?php foreach($addrList as $id => $addr) { ?>
					  <option value='<?= $id ?>'><?= $addr ?></option>
				<?php } ?>
				</select>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="shipping_mode_<?= $count ?>">Shipping Mode</label>
			  </th>
			  <td>
			  	<select id="shipping_mode_<?= $count ?>" name="order[<?= $count ?>][shipping_mode]">
				  <option value='1'>Overnight</option>
				  <option value='2'>Overland</option>
				  <option value='3'>Detain</option>
				</select>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="amount_<?= $count ?>">COD Amount (PKR)</label>
			  </th>
			  <td>
			  	<input type="text" id="amount_<?= $count ?>" name="order[<?= $count ?>][amount]" value="<?= $orderData['total']?>" required/>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="item_description_<?= $count ?>">Item Description</label>
			  </th>
			  <td>
			  	<textarea id="item_description_<?= $count ?>" name="order[<?= $count ?>][item_description]" required><?= $itemDesc ?></textarea>
			  </td>
		  	</tr>
		  	<tr valign="middle">
			  <th scope="row">
			  	<label for="item_quantity_<?= $count ?>">Item Quantity</label>
			  </th>
			  <td>
			  	<input style='width:60px' type="number" id="item_quantity_<?= $count ?>" name="order[<?= $count ?>][item_quantity]" value="<?= $itemQty ?>" required/>
			  </td>
		  	</tr>
		  <tr valign="middle">
			  <th scope="row">
			  	<label for="spec_instructions_<?= $count ?>">Special Instructions</label>
			  </th>
			  <td>
			  	<textarea id="spec_instructions_<?= $count ?>" name="order[<?= $count ?>][spec_instructions]"><?= $orderData['customer_note']?></textarea>
			  </td>
		  	</tr>
		  </table>
<?php
		}
?>
		  <?php  submit_button(); ?>
	  </form>
	</div>
<?php wp_footer(); ?>

	<?php
}

function trax_register_settings() {
   add_option( 'trax_sonic_api', '');
   register_setting( 'trax_options_group', 'trax_sonic_api', 'trax_callback' );
}
add_action( 'admin_init', 'trax_register_settings' );

function trax_register_options_page() {
  add_options_page('Configure Trax Sonic API', 'Configure Trax Sonic API', 'manage_options', 'trax', 'trax_options_page');
}
add_action('admin_menu', 'trax_register_options_page');

function trax_options_page()
{
?>
  <div>
  <?php screen_icon(); ?>
  <h2>API Credentials | Sonic | Trax</h2>
  <form method="post" action="options.php">
  <?php settings_fields( 'trax_options_group' ); ?>
  <h3>Shipment Booking</h3>
  <table>
  <tr valign="top">
  <th scope="row"><label for="trax_sonic_api">API Key</label></th>
  <td><input type="password" id="trax_sonic_api" name="trax_sonic_api" value="<?php echo get_option('trax_sonic_api'); ?>" /></td>
  </tr>
  </table>
  <?php  submit_button(); ?>
  </form>
  </div>
<?php
}
