document.querySelector('table').addEventListener('click', function(event) {
    if (event.target.classList.contains('remove-row')) {
      const row = event.target.closest('tr');
      if (row) {
        row.remove();
      }
    }
  });
  