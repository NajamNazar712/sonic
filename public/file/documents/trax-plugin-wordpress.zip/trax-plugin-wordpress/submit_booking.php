<?php
if($_POST)
{
	if(isset($_POST['order']))
	{
		$orders = $_POST['order'];
		$apiUrl = "https://sonic.pk/api/cities";

	    $headers = ['Authorization:' . $apiKey, 'Accepts:' . 'application/json'];

		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $apiUrl);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		try
		{
			$result = curl_exec($ch);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}

		$result = json_decode($result,true);

		$cityList = [];

		if($result['status'] == 0)
		{
			$cities = $result['cities'];

			foreach($cities as $city)
			{
				$cityList[$city['id']] = $city['name'];
			}
		}

	    //close connection
		curl_close($ch);

	    $ch = curl_init();

	    $apiUrl = "https://sonic.pk/api/shipment/book";
	    $msgs = '';

	    foreach($orders as $order)
	    {
	    	$cityId = array_search(strtolower($order['consignee_city']), array_map('strtolower', $cityList));

	    	$data = [];
		    $data['order_id'] = $order['order_id'];
		    $data['service_type_id'] = 1;
		    $data['pickup_address_id'] = $order['pickup_address'];
		    $data['information_display'] = 1;
		    $data['consignee_city_id'] = $cityId;
		    $data['consignee_name'] = trim($order['consignee_name']);
		    $data['consignee_address'] = trim($order['consignee_address']);
		    $data['consignee_phone_number_1'] = trim($order['consignee_phone']);

		    if (!empty(trim($order['consignee_email']))) {
			    $data['consignee_email_address'] = trim($order['consignee_email']);
			}

		    $data['item_product_type_id'] = 24;
		    $data['item_description'] = trim($order['item_description']);
		    $data['item_quantity'] = (int)$order['item_quantity'];
		    $data['item_insurance'] = 0;
		    $data['item_price'] = '';
		    $data['pickup_date'] = date('Y-m-d');

		    if(trim($order['spec_instructions']))
		    {
		    	$data['special_instructions'] = trim($order['spec_instructions']);
		    }

		    $data['estimated_weight'] = 1;
		    $data['shipping_mode_id'] = (int)$order['shipping_mode'];
		    $data['amount'] = (double)$order['amount'];
		    $data['payment_mode_id'] = 1;
		    $data['charges_mode_id'] = 4;

			curl_setopt($ch,CURLOPT_URL, $apiUrl);
			curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch,CURLOPT_POST, true);
			curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

			try
			{
				//execute post
				$result = curl_exec($ch);
			}
			catch(Exception $e)
			{
				die($e->getMessage());
			}

			$response = json_decode($result,true);

			$msgs .= "\r\n\r\n<h3><u>Order#".$order['order_id'].'</u></h3>';
			
				$wp_customer_codes_id=$order['order_id'];
			if($response['status'] != 0)
			{
				if (isset($response['errors'])) {
					foreach($response['errors'] as $field => $err)
					{
						$msgs .= "\r\n".$err[0];
					}
				}
				else {
					$msgs .= "\r\n".$response['message'];
				}
			}
			else
			{
				$note = "Shipment has been booked. CN # {$response['tracking_number']}.\r\n<a target='_blank' href=\"https://sonic.pk/tracking?tracking_number={$response['tracking_number']}\">Click to Track order</a>";

				$order = new WC_Order($order['order_id']);
				
				$wp_tracking_number= $response['tracking_number'];

				//Update status
				$order->update_status('trax-booked');

				//Add Order comment
				$order->add_order_note("Order Status updated to Booked at Trax");
				$order->add_order_note($note);

				$msgs .= "\r\n".$response['message'].' Tracking # '.$response['tracking_number'];

					//insert in a table
						global $wpdb;
						$wpdb->insert("wp_trax_new_shipments_table", array(
							"customer_codes_id" => $wp_customer_codes_id,
						   "tracking_number" => $wp_tracking_number,
						 
						));
			}
		}

		//close connection
		curl_close($ch);

	if($msgs!=''){

		wp_head();
		echo '<pre>';
		echo $msgs;
		echo "\r\n";
?>
		<input
			type='button'
			id= 'go-back-btn'
			value='Go Back'
		/>
<?php
		wp_footer();
?>

		<script>
		    document.getElementById("go-back-btn").onclick = function ()
		    {
		        location.href = "<?= get_admin_url(null, 'edit.php?post_type=shop_order') ?>";
		    };
		</script>
<?php
	}
	}
}
