<?php 
/* Creating table for AWB */

function create_awb_table(){
	
	global  $wpdb;
	
    $table_name= $wpdb->prefix."trax_new_shipments_table";
    $table2 ="wp_wc_order_product_lookup";
	
    

    // $sql = "CREATE TABLE `". $table_name . "` ( ";
    // $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
    // $sql .= "  `tracking_number`  int(128)   NOT NULL, ";
    // $sql .= "  `orderID`  int(128) , ";
    // $sql .= "  PRIMARY KEY `key_id` (`id`) "; 
    // $sql .= "  FOREIGN KEY (`orderID`) REFERENCES ".$table2." `order_id` "; 
    // $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";

    $sql=$wpdb->query(
        "CREATE TABLE IF NOT EXISTS $table_name (
            id   INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            customer_codes_id BIGINT UNSIGNED NOT NULL,
            tracking_number BIGINT NOT NULL,
            FOREIGN KEY  (customer_codes_id) REFERENCES $table2(order_id)
        ) ENGINE = INNODB
        DEFAULT CHARACTER SET = utf8
        COLLATE = utf8_general_ci"
    );



    require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    dbDelta($sql);
}

?>