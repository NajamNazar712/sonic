<?php
namespace Sonic\Booking\Block\Adminhtml;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Data\Form\FormKey;
class OrderDetailBlock extends \Magento\Framework\View\Element\Template
{
	protected $formKey;
	protected $collectionFactory;
	protected $filter;
	protected $zendClient;
	protected $jsonHelper;
	public function __construct(\Magento\Framework\View\Element\Template\Context $context,
	 array $data = [],
	 CollectionFactory $collectionFactory,
	 Filter $filter,
	 \Zend\Http\Client $zendClient,
	 \Magento\Framework\Json\Helper\Data $jsonHelper,
     FormKey $formKey
	)
	{
		parent::__construct($context,$data);
		$this->collectionFactory = $collectionFactory;
		$this->filter = $filter;
		$this->zendClient = $zendClient;
		$this->jsonHelper = $jsonHelper;
		$this->formKey = $formKey;
	}

	public function getOrderData()
	{
		$collection = $this->filter->getCollection($this->collectionFactory->create());
		$orderIds = $collection->getAllIds();
		if($orderIds){
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$orders_data = array();
			foreach($orderIds as $order_id){
		    	$order = $objectManager->create('Magento\Sales\Model\Order')->load($order_id);
		    	if($order->getState() == 'new'){

			    	$orders_data[$order_id]['firstname'] = $order->getCustomerFirstname();
			    	$orders_data[$order_id]['lastname'] = $order->getCustomerLastname();

				    $shippingaddress = $order->getShippingAddress();        
					$shippingcity = $shippingaddress->getCity();
					$shippingstreet = $shippingaddress->getStreet();      
					$shippingtelephone = $shippingaddress->getTelephone();
					$customer_address = '';
					foreach ($shippingstreet as $address) {
						$customer_address .= $address.' ';
					}
			    	$orders_data[$order_id]['shipping_address'] = $customer_address;
			    	$orders_data[$order_id]['shipping_city'] = $shippingcity;
			    	$orders_data[$order_id]['shipping_phone'] = $shippingtelephone;
			    	$orders_data[$order_id]['amount'] = (int)$order->getGrandTotal();
			    	$orders_data[$order_id]['status'] = $order->getState();
		    	}

			}
			return $orders_data;
		}
		
	}

	public function getApiKey(){
		$api_key = $this->_scopeConfig->getValue('sonicextension/general/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		return $api_key;
	}

	/**
     * @return string
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }
	public function getFormAction(){
		return $this->getRequest()->getParams();
	}

	public function getPickupAddress(){
		$SONIC_URL = 'https://sonic.pk/api/';

		try {
            $api_key = $this->getApiKey();
            if($api_key){
            	 	$this->zendClient->reset();
		            $this->zendClient->setUri($SONIC_URL.'pickup_addresses');
		            $this->zendClient->setMethod(\Zend\Http\Request::METHOD_GET); 
		            $this->zendClient->setHeaders([
		                'Content-Type' => 'application/json',
		                'Accept' => 'application/json',
		                'Authorization' => $api_key,
		            ]);
		            
		            $this->zendClient->send();
		            $response = $this->zendClient->getResponse();
		            
		            $response_body = $response->getBody();
		            $response_data =  $this->jsonHelper->jsonDecode($response_body);
		            
		            if($response_data['status'] == 0){
		            	return $response_data['pickup_addresses'];
		            }
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
	}

	public function getCities(){
		$SONIC_URL = 'https://sonic.pk/api/';
		try {
            $api_key = $this->getApiKey();
            if($api_key){
            	 	$this->zendClient->reset();
		            $this->zendClient->setUri($SONIC_URL.'cities');
		            $this->zendClient->setMethod(\Zend\Http\Request::METHOD_GET); 
		            $this->zendClient->setHeaders([
		                'Content-Type' => 'application/json',
		                'Accept' => 'application/json',
		                'Authorization' => $api_key,
		            ]);
		            
		            $this->zendClient->send();
		            $response = $this->zendClient->getResponse();
		            
		            $response_body = $response->getBody();
		            $response_data =  $this->jsonHelper->jsonDecode($response_body);
		            
		            if($response_data['status'] == 0){
		            	return $response_data['cities'];
		            }
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
	}
}